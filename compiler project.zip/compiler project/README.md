# Aether Compiler: Mid-Level Programming Language Compiler

Aether is a modular, scope-aware **mid-level compiler** implemented in pure Python (no external dependencies). It demonstrates the main phases of compiler construction—from scanner tokenization to final target assembly code generation.

The project features a **premium, interactive web visualization dashboard** designed to run locally, providing a side-by-side view of each compiler stage in real-time.

---

## Deliverables Checklist
1. **Source Code**: Fully modular structure in `mini_compiler/` package.
2. **User Manual**: This document (`README.md`) outlines language syntax, specifications, and architecture.
3. **Sample Inputs & Outputs**: Included in the `tests/` directory and integrated directly into the web dashboard presets.
4. **Live Demonstration**: Easy launch via the interactive browser UI using `python main.py --web`.

---

## Language Specifications

Aether compiles a simple C-like imperative programming language supporting:
*   **Data Types**: `int`, `float`, `char`, `bool`, `string`, `void`
*   **Variable Declarations**: E.g., `int x = 10;`, `float y;`
*   **Functions**: Declared via `func <type> <name>(<params>) { <body> }` and called via expression calls. Supports return statements matching function signatures.
*   **Operators**:
    *   *Arithmetic*: `+`, `-`, `*`, `/`, `%`
    *   *Assignment*: `=`
    *   *Relational*: `<`, `>`, `<=`, `>=`, `==`, `!=`
    *   *Logical*: `&&`, `||`, `!`
*   **Control Flow**:
    *   `if (condition) { ... } else { ... }`
    *   `while (condition) { ... }`
    *   `for (init; condition; post) { ... }`
*   **Built-in Functions**:
    *   `print(expression);` - Prints an expression value.
    *   `input(variable);` - Reads an input into a variable.
*   **Comments**:
    *   Single-line: `// comment`
    *   Multi-line: `/* comment */`

---

## Compiler Phases

### Phase 1: Lexical Analysis (Scanner)
Located in `mini_compiler/lexer.py`. Reads raw character sequences and converts them into token structures, tracking exact line and column locations. Lexical errors are collected and reported with coordinates.

### Phase 2: Syntax Analysis (Parser)
Located in `mini_compiler/parser.py`. Implements a **Recursive Descent Parser** that maps tokens to an Abstract Syntax Tree (AST). It incorporates statement synchronization, allowing it to recover from errors and report multiple syntax errors at once.

### Phase 3: Symbol Table
Located in `mini_compiler/symbol_table.py`. Tracks variable names, functions, parameters, scopes, types, and declaration positions. It implements stack-based push/pop actions for block scopes.

### Phase 4: Semantic Analysis
Located in `mini_compiler/semantic.py`. Walks the AST with the symbol table to enforce type safety rules. It flags:
*   Undeclared variables and duplicate declarations.
*   Type mismatches in assignments and expressions.
*   Function argument size and type compatibility.
*   Invalid return types.

### Phase 5: Intermediate Code Generation (TAC)
Located in `mini_compiler/tac.py`. Flattens nested expressions and control flows into Three-Address Code (TAC) with temporary variables (`t1`, `t2`, etc.) and jump labels (`L1`, `L2`, etc.).

### Phase 6: Code Optimization
Located in `mini_compiler/optimizer.py`. Performs multiple optimization passes on the TAC until a fixed-point is reached:
1.  **Constant Folding**: Pre-calculating constant operations (e.g., `5 * 4` to `20`).
2.  **Constant Propagation**: Replacing variables containing constants with their values.
3.  **Common Subexpression Elimination (CSE)**: Reusing matching calculations to avoid redundant evaluations.
4.  **Dead Code Elimination (DCE)**: Removing unused temporary variables and assignments.

### Phase 7: Target Code Generation (Assembly)
Located in `mini_compiler/target_gen.py`. Converts optimized TAC to register-level assembly instructions using virtual registers (`R1`-`R5`), including parameter pushing, function prologues/epilogues, and ret instructions.

---

## Execution Guide

### 1. Launching the Interactive Web Dashboard (Recommended)
This runs a zero-dependency local HTTP server and opens a visual browser panel:
```bash
python main.py --web
```
*   **URL**: Open your browser to `http://localhost:8000`.
*   **Features**: Select any preset program on the top right (Full Program, Syntax Error, Semantic Error, Optimization Demo), edit the code live, and click **Run Compiler Engine** to visualize the compilation process in real-time.

### 2. Using the Command-Line Interface (CLI)
You can compile any source file directly in the console:
```bash
# Compile the valid test program
python main.py tests/sample_valid.txt

# Compile the syntax error program
python main.py tests/sample_syntax_err.txt

# Compile the semantic error program
python main.py tests/sample_semantic_err.txt

# Compile the optimization program
python main.py tests/sample_optimize.txt
```
The CLI will print:
*   Tokens stream with line:col tracking.
*   Function signatures and scopes.
*   Initial TAC vs. Optimized TAC.
*   Generated Assembly code.
*   Diagnostic logs for any compilation errors.
