class ASTNode:
    def to_dict(self):
        raise NotImplementedError()


# Program & Structure Nodes
class Program(ASTNode):
    def __init__(self, statements):
        self.statements = statements

    def to_dict(self):
        return {
            "node_type": "Program",
            "statements": [stmt.to_dict() for stmt in self.statements]
        }


class VarDecl(ASTNode):
    def __init__(self, type_name, var_name, initializer, line, col):
        self.type_name = type_name
        self.var_name = var_name
        self.initializer = initializer
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "VarDecl",
            "type_name": self.type_name,
            "var_name": self.var_name,
            "initializer": self.initializer.to_dict() if self.initializer else None,
            "line": self.line,
            "column": self.col
        }


class FuncDecl(ASTNode):
    def __init__(self, return_type, func_name, params, body, line, col):
        self.return_type = return_type
        self.func_name = func_name
        self.params = params  # List of (type, name, line, col)
        self.body = body  # BlockStmt
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "FuncDecl",
            "return_type": self.return_type,
            "func_name": self.func_name,
            "params": [{"type": p[0], "name": p[1]} for p in self.params],
            "body": self.body.to_dict(),
            "line": self.line,
            "column": self.col
        }


# Statement Nodes
class ReturnStmt(ASTNode):
    def __init__(self, expression, line, col):
        self.expression = expression
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "ReturnStmt",
            "expression": self.expression.to_dict() if self.expression else None,
            "line": self.line,
            "column": self.col
        }


class AssignStmt(ASTNode):
    def __init__(self, var_name, value, line, col):
        self.var_name = var_name
        self.value = value
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "AssignStmt",
            "var_name": self.var_name,
            "value": self.value.to_dict(),
            "line": self.line,
            "column": self.col
        }


class PrintStmt(ASTNode):
    def __init__(self, expression, line, col):
        self.expression = expression
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "PrintStmt",
            "expression": self.expression.to_dict(),
            "line": self.line,
            "column": self.col
        }


class InputStmt(ASTNode):
    def __init__(self, var_name, line, col):
        self.var_name = var_name
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "InputStmt",
            "var_name": self.var_name,
            "line": self.line,
            "column": self.col
        }


class IfStmt(ASTNode):
    def __init__(self, condition, then_branch, else_branch, line, col):
        self.condition = condition
        self.then_branch = then_branch
        self.else_branch = else_branch
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "IfStmt",
            "condition": self.condition.to_dict(),
            "then_branch": self.then_branch.to_dict(),
            "else_branch": self.else_branch.to_dict() if self.else_branch else None,
            "line": self.line,
            "column": self.col
        }


class WhileStmt(ASTNode):
    def __init__(self, condition, body, line, col):
        self.condition = condition
        self.body = body
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "WhileStmt",
            "condition": self.condition.to_dict(),
            "body": self.body.to_dict(),
            "line": self.line,
            "column": self.col
        }


class ForStmt(ASTNode):
    def __init__(self, init, condition, post, body, line, col):
        self.init = init
        self.condition = condition
        self.post = post
        self.body = body
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "ForStmt",
            "init": self.init.to_dict() if self.init else None,
            "condition": self.condition.to_dict() if self.condition else None,
            "post": self.post.to_dict() if self.post else None,
            "body": self.body.to_dict(),
            "line": self.line,
            "column": self.col
        }


class BlockStmt(ASTNode):
    def __init__(self, statements, line, col):
        self.statements = statements
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "BlockStmt",
            "statements": [stmt.to_dict() for stmt in self.statements],
            "line": self.line,
            "column": self.col
        }


# Expression Nodes
class BinaryOp(ASTNode):
    def __init__(self, op, left, right, line, col):
        self.op = op
        self.left = left
        self.right = right
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "BinaryOp",
            "op": self.op,
            "left": self.left.to_dict(),
            "right": self.right.to_dict(),
            "line": self.line,
            "column": self.col
        }


class UnaryOp(ASTNode):
    def __init__(self, op, expr, line, col):
        self.op = op
        self.expr = expr
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "UnaryOp",
            "op": self.op,
            "expr": self.expr.to_dict(),
            "line": self.line,
            "column": self.col
        }


class Literal(ASTNode):
    def __init__(self, type_, value, line, col):
        self.type = type_  # INT, FLOAT, STRING, CHAR, BOOL
        self.value = value
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "Literal",
            "type": self.type,
            "value": self.value,
            "line": self.line,
            "column": self.col
        }


class Identifier(ASTNode):
    def __init__(self, name, line, col):
        self.name = name
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "Identifier",
            "name": self.name,
            "line": self.line,
            "column": self.col
        }


class FuncCall(ASTNode):
    def __init__(self, func_name, args, line, col):
        self.func_name = func_name
        self.args = args
        self.line = line
        self.col = col

    def to_dict(self):
        return {
            "node_type": "FuncCall",
            "func_name": self.func_name,
            "args": [arg.to_dict() for arg in self.args],
            "line": self.line,
            "column": self.col
        }


class ParserError(Exception):
    def __init__(self, message, line, column):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(f"Syntax Error at line {line}, column {column}: {message}")


class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0
        self.errors = []

    def peek(self, offset=0):
        if self.pos + offset >= len(self.tokens):
            return self.tokens[-1]  # Return EOF token
        return self.tokens[self.pos + offset]

    def advance(self):
        token = self.peek()
        if self.pos < len(self.tokens):
            self.pos += 1
        return token

    def check(self, type_, lexeme=None):
        tok = self.peek()
        if tok.type != type_:
            return False
        if lexeme is not None and tok.lexeme != lexeme:
            return False
        return True

    def match(self, type_, lexeme=None):
        if self.check(type_, lexeme):
            return self.advance()
        return None

    def consume(self, type_, lexeme=None, err_msg=""):
        token = self.match(type_, lexeme)
        if token:
            return token
        peek_tok = self.peek()
        msg = err_msg or f"Expected {type_} {f'({lexeme})' if lexeme else ''}, found '{peek_tok.lexeme}'"
        raise ParserError(msg, peek_tok.line, peek_tok.column)

    def synchronize(self):
        # Discard tokens until we see a potential statement boundary
        self.advance()
        while self.pos < len(self.tokens):
            tok = self.peek()
            if tok.type == "EOF":
                break
            if tok.lexeme == ";":
                self.advance()
                break
            if tok.lexeme in ("func", "if", "while", "for", "print", "input", "return", "{", "}"):
                break
            # Or type names
            if tok.lexeme in ("int", "float", "char", "bool", "string", "void"):
                break
            self.advance()

    def parse(self):
        statements = []
        while self.peek().type != "EOF":
            try:
                stmt = self.parse_global_or_statement()
                if stmt:
                    statements.append(stmt)
            except ParserError as e:
                self.errors.append(e)
                self.synchronize()
        return Program(statements), self.errors

    def parse_global_or_statement(self):
        # We allow function declarations or regular statements at global level
        # A function declaration starts with: "func" or "void"/"int"/... followed by ID "("?
        # Let's check for "func" explicitly to make it unambiguous:
        # func int name(...) { ... } or func void name(...) { ... }
        if self.check("KEYWORD", "func"):
            return self.parse_function_declaration()
        return self.parse_statement()

    def parse_function_declaration(self):
        start_tok = self.consume("KEYWORD", "func")
        # Return type: void, int, float, char, bool, string
        ret_type_tok = self.peek()
        if ret_type_tok.lexeme not in ("void", "int", "float", "char", "bool", "string"):
            raise ParserError(f"Invalid return type '{ret_type_tok.lexeme}' for function", ret_type_tok.line, ret_type_tok.column)
        self.advance()

        func_name_tok = self.consume("IDENTIFIER", err_msg="Expected function name after return type")
        
        self.consume("DELIMITER", "(", err_msg="Expected '(' after function name")
        params = []
        if not self.check("DELIMITER", ")"):
            while True:
                # Param type
                pt_tok = self.peek()
                if pt_tok.lexeme not in ("int", "float", "char", "bool", "string"):
                    raise ParserError(f"Expected parameter type, found '{pt_tok.lexeme}'", pt_tok.line, pt_tok.column)
                self.advance()

                p_name_tok = self.consume("IDENTIFIER", err_msg="Expected parameter name after type")
                params.append((pt_tok.lexeme, p_name_tok.lexeme, pt_tok.line, pt_tok.column))

                if not self.match("DELIMITER", ","):
                    break
        self.consume("DELIMITER", ")", err_msg="Expected ')' after parameters")
        
        body = self.parse_block_statement()
        return FuncDecl(ret_type_tok.lexeme, func_name_tok.lexeme, params, body, start_tok.line, start_tok.column)

    def parse_statement(self):
        # Determine statement type
        tok = self.peek()
        if tok.lexeme in ("int", "float", "char", "bool", "string"):
            return self.parse_variable_declaration()
        elif tok.lexeme == "if":
            return self.parse_if_statement()
        elif tok.lexeme == "while":
            return self.parse_while_statement()
        elif tok.lexeme == "for":
            return self.parse_for_statement()
        elif tok.lexeme == "print":
            return self.parse_print_statement()
        elif tok.lexeme == "input":
            return self.parse_input_statement()
        elif tok.lexeme == "return":
            return self.parse_return_statement()
        elif tok.lexeme == "{":
            return self.parse_block_statement()
        elif tok.type == "IDENTIFIER":
            # Can be assignment or expression statement
            return self.parse_assignment_statement()
        else:
            raise ParserError(f"Unexpected token '{tok.lexeme}'", tok.line, tok.column)

    def parse_variable_declaration(self):
        type_tok = self.advance() # type
        var_tok = self.consume("IDENTIFIER", err_msg="Expected variable name after type")
        
        initializer = None
        if self.match("OPERATOR", "="):
            initializer = self.parse_expression()
            
        self.consume("DELIMITER", ";", err_msg="Expected ';' at the end of declaration")
        return VarDecl(type_tok.lexeme, var_tok.lexeme, initializer, type_tok.line, type_tok.column)

    def parse_assignment_statement(self):
        var_tok = self.consume("IDENTIFIER")
        self.consume("OPERATOR", "=", err_msg="Expected '=' after variable name in assignment")
        expr = self.parse_expression()
        self.consume("DELIMITER", ";", err_msg="Expected ';' at the end of assignment")
        return AssignStmt(var_tok.lexeme, expr, var_tok.line, var_tok.column)

    def parse_print_statement(self):
        start_tok = self.consume("KEYWORD", "print")
        self.consume("DELIMITER", "(", err_msg="Expected '(' after print")
        expr = self.parse_expression()
        self.consume("DELIMITER", ")", err_msg="Expected ')' after expression")
        self.consume("DELIMITER", ";", err_msg="Expected ';' after print statement")
        return PrintStmt(expr, start_tok.line, start_tok.column)

    def parse_input_statement(self):
        start_tok = self.consume("KEYWORD", "input")
        self.consume("DELIMITER", "(", err_msg="Expected '(' after input")
        var_tok = self.consume("IDENTIFIER", err_msg="Expected variable name inside input()")
        self.consume("DELIMITER", ")", err_msg="Expected ')' after variable name")
        self.consume("DELIMITER", ";", err_msg="Expected ';' after input statement")
        return InputStmt(var_tok.lexeme, start_tok.line, start_tok.column)

    def parse_return_statement(self):
        start_tok = self.consume("KEYWORD", "return")
        expr = None
        if not self.check("DELIMITER", ";"):
            expr = self.parse_expression()
        self.consume("DELIMITER", ";", err_msg="Expected ';' after return statement")
        return ReturnStmt(expr, start_tok.line, start_tok.column)

    def parse_block_statement(self):
        start_tok = self.consume("DELIMITER", "{")
        statements = []
        while not self.check("DELIMITER", "}") and self.peek().type != "EOF":
            try:
                stmt = self.parse_statement()
                if stmt:
                    statements.append(stmt)
            except ParserError as e:
                self.errors.append(e)
                self.synchronize()
        self.consume("DELIMITER", "}", err_msg="Expected '}' to close block")
        return BlockStmt(statements, start_tok.line, start_tok.column)

    def parse_if_statement(self):
        start_tok = self.consume("KEYWORD", "if")
        self.consume("DELIMITER", "(", err_msg="Expected '(' after if")
        cond = self.parse_expression()
        self.consume("DELIMITER", ")", err_msg="Expected ')' after if condition")
        
        then_branch = self.parse_statement()
        else_branch = None
        if self.match("KEYWORD", "else"):
            else_branch = self.parse_statement()
            
        return IfStmt(cond, then_branch, else_branch, start_tok.line, start_tok.column)

    def parse_while_statement(self):
        start_tok = self.consume("KEYWORD", "while")
        self.consume("DELIMITER", "(", err_msg="Expected '(' after while")
        cond = self.parse_expression()
        self.consume("DELIMITER", ")", err_msg="Expected ')' after while condition")
        body = self.parse_statement()
        return WhileStmt(cond, body, start_tok.line, start_tok.column)

    def parse_for_statement(self):
        start_tok = self.consume("KEYWORD", "for")
        self.consume("DELIMITER", "(", err_msg="Expected '(' after for")
        
        # Init
        init = None
        if not self.check("DELIMITER", ";"):
            tok = self.peek()
            if tok.lexeme in ("int", "float", "char", "bool", "string"):
                init = self.parse_variable_declaration()
            else:
                # Custom assignment parsing without semicolon consume
                var_tok = self.consume("IDENTIFIER")
                self.consume("OPERATOR", "=", err_msg="Expected '=' in for init assignment")
                expr = self.parse_expression()
                init = AssignStmt(var_tok.lexeme, expr, var_tok.line, var_tok.column)
                self.consume("DELIMITER", ";", err_msg="Expected ';' after for init assignment")
        else:
            self.consume("DELIMITER", ";")

        # Condition
        condition = None
        if not self.check("DELIMITER", ";"):
            condition = self.parse_expression()
        self.consume("DELIMITER", ";", err_msg="Expected ';' after for condition")

        # Post
        post = None
        if not self.check("DELIMITER", ")"):
            var_tok = self.consume("IDENTIFIER")
            self.consume("OPERATOR", "=", err_msg="Expected '=' in for loop update")
            expr = self.parse_expression()
            post = AssignStmt(var_tok.lexeme, expr, var_tok.line, var_tok.column)
        
        self.consume("DELIMITER", ")", err_msg="Expected ')' to close for header")
        
        body = self.parse_statement()
        return ForStmt(init, condition, post, body, start_tok.line, start_tok.column)

    # Expression parsing (Operator Precedence)
    def parse_expression(self):
        return self.parse_logical_or()

    def parse_logical_or(self):
        left = self.parse_logical_and()
        while True:
            op_tok = self.match("OPERATOR", "||")
            if not op_tok:
                break
            right = self.parse_logical_and()
            left = BinaryOp("||", left, right, op_tok.line, op_tok.column)
        return left

    def parse_logical_and(self):
        left = self.parse_equality()
        while True:
            op_tok = self.match("OPERATOR", "&&")
            if not op_tok:
                break
            right = self.parse_equality()
            left = BinaryOp("&&", left, right, op_tok.line, op_tok.column)
        return left

    def parse_equality(self):
        left = self.parse_relational()
        while True:
            op_tok = self.match("OPERATOR", "==") or self.match("OPERATOR", "!=")
            if not op_tok:
                break
            right = self.parse_relational()
            left = BinaryOp(op_tok.lexeme, left, right, op_tok.line, op_tok.column)
        return left

    def parse_relational(self):
        left = self.parse_additive()
        while True:
            op_tok = (self.match("OPERATOR", "<") or 
                      self.match("OPERATOR", ">") or 
                      self.match("OPERATOR", "<=") or 
                      self.match("OPERATOR", ">="))
            if not op_tok:
                break
            right = self.parse_additive()
            left = BinaryOp(op_tok.lexeme, left, right, op_tok.line, op_tok.column)
        return left

    def parse_additive(self):
        left = self.parse_multiplicative()
        while True:
            op_tok = self.match("OPERATOR", "+") or self.match("OPERATOR", "-")
            if not op_tok:
                break
            right = self.parse_multiplicative()
            left = BinaryOp(op_tok.lexeme, left, right, op_tok.line, op_tok.column)
        return left

    def parse_multiplicative(self):
        left = self.parse_unary()
        while True:
            op_tok = (self.match("OPERATOR", "*") or 
                      self.match("OPERATOR", "/") or 
                      self.match("OPERATOR", "%"))
            if not op_tok:
                break
            right = self.parse_unary()
            left = BinaryOp(op_tok.lexeme, left, right, op_tok.line, op_tok.column)
        return left

    def parse_unary(self):
        op_tok = self.match("OPERATOR", "!") or self.match("OPERATOR", "-")
        if op_tok:
            expr = self.parse_unary()
            return UnaryOp(op_tok.lexeme, expr, op_tok.line, op_tok.column)
        return self.parse_primary()

    def parse_primary(self):
        tok = self.peek()
        
        # Parenthesized expression
        if self.match("DELIMITER", "("):
            expr = self.parse_expression()
            self.consume("DELIMITER", ")", err_msg="Expected ')' to close expression")
            return expr

        # Literals
        if self.check("INT_LIT"):
            t = self.advance()
            return Literal("INT", int(t.lexeme), t.line, t.column)
        elif self.check("FLOAT_LIT"):
            t = self.advance()
            return Literal("FLOAT", float(t.lexeme), t.line, t.column)
        elif self.check("STRING_LIT"):
            t = self.advance()
            return Literal("STRING", t.lexeme, t.line, t.column)
        elif self.check("CHAR_LIT"):
            t = self.advance()
            return Literal("CHAR", t.lexeme, t.line, t.column)
        elif self.check("BOOL_LIT"):
            t = self.advance()
            val = True if t.lexeme == "true" else False
            return Literal("BOOL", val, t.line, t.column)
            
        # Identifier or Function Call
        if self.check("IDENTIFIER"):
            id_tok = self.advance()
            
            # Check for function call
            if self.match("DELIMITER", "("):
                args = []
                if not self.check("DELIMITER", ")"):
                    while True:
                        args.append(self.parse_expression())
                        if not self.match("DELIMITER", ","):
                            break
                self.consume("DELIMITER", ")", err_msg="Expected ')' after function arguments")
                return FuncCall(id_tok.lexeme, args, id_tok.line, id_tok.column)
                
            return Identifier(id_tok.lexeme, id_tok.line, id_tok.column)

        raise ParserError(f"Expected expression, found '{tok.lexeme}'", tok.line, tok.column)
