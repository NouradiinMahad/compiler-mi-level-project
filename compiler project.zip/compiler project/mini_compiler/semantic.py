from .symbol_table import SymbolTable

class SemanticError(Exception):
    def __init__(self, message, line, column):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(f"Semantic Error at line {line}, column {column}: {message}")


class SemanticAnalyzer:
    def __init__(self):
        self.symbol_table = SymbolTable()
        self.errors = []
        self.current_function = None  # To track the return type of the enclosing function

    def analyze(self, program_node):
        # We perform a first pass to register all function declarations globally
        # so that functions can call each other, even if declared later (forward references)
        for stmt in program_node.statements:
            if stmt.to_dict()["node_type"] == "FuncDecl":
                self.register_function_signature(stmt)

        # Second pass: Full semantic analysis
        for stmt in program_node.statements:
            try:
                self.visit(stmt)
            except SemanticError as e:
                self.errors.append(e)

        return self.errors, self.symbol_table

    def register_function_signature(self, node):
        # Check if already declared
        existing = self.symbol_table.lookup(node.func_name)
        if existing:
            self.errors.append(SemanticError(f"Duplicate declaration of function '{node.func_name}'", node.line, node.col))
            return
        
        # Register signature
        param_sigs = [(p[0], p[1]) for p in node.params] # (type, name)
        self.symbol_table.declare(
            name=node.func_name,
            type_=node.return_type,
            category="function",
            line=node.line,
            col=node.col,
            params=param_sigs
        )

    def visit(self, node):
        method_name = f"visit_{node.__class__.__name__}"
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node):
        raise Exception(f"No visit_{node.__class__.__name__} method defined")

    def visit_Program(self, node):
        for stmt in node.statements:
            try:
                self.visit(stmt)
            except SemanticError as e:
                self.errors.append(e)

    def visit_VarDecl(self, node):
        # Declare in symbol table
        success = self.symbol_table.declare(
            name=node.var_name,
            type_=node.type_name,
            category="variable",
            line=node.line,
            col=node.col
        )
        if not success:
            raise SemanticError(f"Variable '{node.var_name}' is already declared in this scope", node.line, node.col)

        # Check initializer if present
        if node.initializer:
            init_type = self.visit(node.initializer)
            if not self.are_types_compatible(node.type_name, init_type):
                raise SemanticError(f"Cannot initialize variable of type '{node.type_name}' with value of type '{init_type}'", node.line, node.col)
        
        node.resolved_type = node.type_name
        return node.type_name

    def visit_FuncDecl(self, node):
        # Note: Function signature was already registered in the first pass
        # Now we analyze the parameters and the body
        self.current_function = node
        self.symbol_table.enter_scope()

        # Declare parameters inside the function scope
        for param_type, param_name, pline, pcol in node.params:
            success = self.symbol_table.declare(
                name=param_name,
                type_=param_type,
                category="variable",
                line=pline,
                col=pcol
            )
            if not success:
                self.errors.append(SemanticError(f"Duplicate parameter name '{param_name}' in function '{node.func_name}'", pline, pcol))

        # Check body statements
        for stmt in node.body.statements:
            try:
                self.visit(stmt)
            except SemanticError as e:
                self.errors.append(e)

        self.symbol_table.exit_scope()
        self.current_function = None

    def visit_ReturnStmt(self, node):
        if not self.current_function:
            raise SemanticError("Return statement is not inside a function", node.line, node.col)

        expected_type = self.current_function.return_type
        
        if node.expression:
            actual_type = self.visit(node.expression)
            if expected_type == "void":
                raise SemanticError("Cannot return a value from a void function", node.line, node.col)
            if not self.are_types_compatible(expected_type, actual_type):
                raise SemanticError(f"Type mismatch: function '{self.current_function.func_name}' expects to return '{expected_type}', but got '{actual_type}'", node.line, node.col)
        else:
            if expected_type != "void":
                raise SemanticError(f"Function '{self.current_function.func_name}' expects a return value of type '{expected_type}'", node.line, node.col)
        
        node.resolved_type = "void"
        return "void"

    def visit_AssignStmt(self, node):
        symbol = self.symbol_table.lookup(node.var_name)
        if not symbol:
            raise SemanticError(f"Undeclared variable '{node.var_name}'", node.line, node.col)
        if symbol.category != "variable":
            raise SemanticError(f"Cannot assign to non-variable '{node.var_name}'", node.line, node.col)

        val_type = self.visit(node.value)
        if not self.are_types_compatible(symbol.type, val_type):
            raise SemanticError(f"Type mismatch: Cannot assign type '{val_type}' to variable '{node.var_name}' of type '{symbol.type}'", node.line, node.col)
        
        node.resolved_type = symbol.type
        return symbol.type

    def visit_PrintStmt(self, node):
        self.visit(node.expression)
        node.resolved_type = "void"
        return "void"

    def visit_InputStmt(self, node):
        symbol = self.symbol_table.lookup(node.var_name)
        if not symbol:
            raise SemanticError(f"Undeclared variable '{node.var_name}' in input statement", node.line, node.col)
        if symbol.category != "variable":
            raise SemanticError(f"Cannot read into non-variable '{node.var_name}'", node.line, node.col)
        node.resolved_type = "void"
        return "void"

    def visit_BlockStmt(self, node):
        self.symbol_table.enter_scope()
        for stmt in node.statements:
            try:
                self.visit(stmt)
            except SemanticError as e:
                self.errors.append(e)
        self.symbol_table.exit_scope()
        node.resolved_type = "void"
        return "void"

    def visit_IfStmt(self, node):
        cond_type = self.visit(node.condition)
        if cond_type not in ("bool", "int"):
            raise SemanticError(f"Condition in 'if' must be bool or int, found '{cond_type}'", node.line, node.col)
        
        self.visit(node.then_branch)
        if node.else_branch:
            self.visit(node.else_branch)
            
        node.resolved_type = "void"
        return "void"

    def visit_WhileStmt(self, node):
        cond_type = self.visit(node.condition)
        if cond_type not in ("bool", "int"):
            raise SemanticError(f"Condition in 'while' must be bool or int, found '{cond_type}'", node.line, node.col)
            
        self.visit(node.body)
        node.resolved_type = "void"
        return "void"

    def visit_ForStmt(self, node):
        self.symbol_table.enter_scope() # For loop header can declare loop variable
        if node.init:
            self.visit(node.init)
        if node.condition:
            cond_type = self.visit(node.condition)
            if cond_type not in ("bool", "int"):
                raise SemanticError(f"Condition in 'for' loop header must be bool or int, found '{cond_type}'", node.line, node.col)
        if node.post:
            self.visit(node.post)
            
        self.visit(node.body)
        self.symbol_table.exit_scope()
        node.resolved_type = "void"
        return "void"

    # Expression visitors
    def visit_BinaryOp(self, node):
        left_type = self.visit(node.left)
        right_type = self.visit(node.right)

        # Arithmetic operators
        if node.op in ("+", "-", "*", "/", "%"):
            if node.op == "%" and (left_type != "int" or right_type != "int"):
                raise SemanticError("Modulo operator '%' is only defined for integer types", node.line, node.col)
            
            if left_type == "int" and right_type == "int":
                node.resolved_type = "int"
                return "int"
            elif left_type in ("int", "float") and right_type in ("int", "float"):
                node.resolved_type = "float"
                return "float"
            else:
                raise SemanticError(f"Operator '{node.op}' cannot be applied to types '{left_type}' and '{right_type}'", node.line, node.col)

        # Relational operators
        elif node.op in ("<", ">", "<=", ">="):
            if left_type in ("int", "float") and right_type in ("int", "float"):
                node.resolved_type = "bool"
                return "bool"
            else:
                raise SemanticError(f"Relational operator '{node.op}' cannot be applied to types '{left_type}' and '{right_type}'", node.line, node.col)

        # Equality operators
        elif node.op in ("==", "!="):
            if self.are_types_compatible(left_type, right_type) or self.are_types_compatible(right_type, left_type):
                node.resolved_type = "bool"
                return "bool"
            else:
                raise SemanticError(f"Equality operator '{node.op}' cannot be applied to incompatible types '{left_type}' and '{right_type}'", node.line, node.col)

        # Logical operators
        elif node.op in ("&&", "||"):
            if left_type == "bool" and right_type == "bool":
                node.resolved_type = "bool"
                return "bool"
            else:
                raise SemanticError(f"Logical operator '{node.op}' requires both operands to be of type 'bool', found '{left_type}' and '{right_type}'", node.line, node.col)

        raise SemanticError(f"Unknown binary operator '{node.op}'", node.line, node.col)

    def visit_UnaryOp(self, node):
        expr_type = self.visit(node.expr)

        if node.op == "-":
            if expr_type in ("int", "float"):
                node.resolved_type = expr_type
                return expr_type
            raise SemanticError(f"Unary operator '-' requires a numeric operand, found '{expr_type}'", node.line, node.col)

        elif node.op == "!":
            if expr_type == "bool":
                node.resolved_type = "bool"
                return "bool"
            raise SemanticError(f"Unary operator '!' requires a boolean operand, found '{expr_type}'", node.line, node.col)

        raise SemanticError(f"Unknown unary operator '{node.op}'", node.line, node.col)

    def visit_Literal(self, node):
        # Map literals to basic compiler types
        mapping = {
            "INT": "int",
            "FLOAT": "float",
            "STRING": "string",
            "CHAR": "char",
            "BOOL": "bool"
        }
        res_type = mapping.get(node.type, "void")
        node.resolved_type = res_type
        return res_type

    def visit_Identifier(self, node):
        symbol = self.symbol_table.lookup(node.name)
        if not symbol:
            raise SemanticError(f"Undeclared variable '{node.name}'", node.line, node.col)
        if symbol.category != "variable":
            raise SemanticError(f"Identifier '{node.name}' is not a variable", node.line, node.col)
        node.resolved_type = symbol.type
        return symbol.type

    def visit_FuncCall(self, node):
        symbol = self.symbol_table.lookup(node.func_name)
        if not symbol:
            raise SemanticError(f"Undeclared function '{node.func_name}'", node.line, node.col)
        if symbol.category != "function":
            raise SemanticError(f"Identifier '{node.func_name}' is not a function", node.line, node.col)

        # Check parameter count
        expected_params = symbol.params or []
        if len(node.args) != len(expected_params):
            raise SemanticError(f"Function '{node.func_name}' expects {len(expected_params)} arguments, but got {len(node.args)}", node.line, node.col)

        # Check argument types
        for i, arg in enumerate(node.args):
            arg_type = self.visit(arg)
            expected_type, _ = expected_params[i]
            if not self.are_types_compatible(expected_type, arg_type):
                raise SemanticError(f"Argument {i+1} of function '{node.func_name}' expects type '{expected_type}', but got '{arg_type}'", node.line, node.col)

        node.resolved_type = symbol.type
        return symbol.type

    def are_types_compatible(self, target, source):
        # Strict rules:
        # target == source: compatible
        if target == source:
            return True
        # Coercion: int can be assigned to float
        if target == "float" and source == "int":
            return True
        return False
