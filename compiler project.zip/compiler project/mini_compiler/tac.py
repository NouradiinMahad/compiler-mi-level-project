class TacInstruction:
    def __init__(self, op, arg1=None, arg2=None, result=None):
        self.op = op          # Operators: '+', '-', '*', '/', '%', '=', 'label', 'ifFalse', 'goto', 'print', 'input', 'param', 'call', 'return', 'func_begin', 'func_end'
        self.arg1 = arg1
        self.arg2 = arg2
        self.result = result  # Target variable or label name

    def to_dict(self):
        return {
            "op": self.op,
            "arg1": str(self.arg1) if self.arg1 is not None else None,
            "arg2": str(self.arg2) if self.arg2 is not None else None,
            "result": str(self.result) if self.result is not None else None
        }

    def __repr__(self):
        if self.op == 'label':
            return f"label {self.result}:"
        elif self.op == 'goto':
            return f"goto {self.result}"
        elif self.op == 'ifFalse':
            return f"ifFalse {self.arg1} goto {self.result}"
        elif self.op == 'print':
            return f"print {self.arg1}"
        elif self.op == 'input':
            return f"input {self.result}"
        elif self.op == 'param':
            return f"param {self.arg1}"
        elif self.op == 'call':
            if self.result:
                return f"{self.result} = call {self.arg1}, {self.arg2}"
            return f"call {self.arg1}, {self.arg2}"
        elif self.op == 'return':
            if self.arg1 is not None:
                return f"return {self.arg1}"
            return "return"
        elif self.op == 'func_begin':
            return f"func {self.result} begin"
        elif self.op == 'func_end':
            return f"func {self.result} end"
        elif self.op == '=':
            return f"{self.result} = {self.arg1}"
        elif self.op in ('+', '-', '*', '/', '%', '<', '>', '<=', '>=', '==', '!=', '&&', '||'):
            return f"{self.result} = {self.arg1} {self.op} {self.arg2}"
        else:
            return f"{self.result} = {self.op} {self.arg1}"


class TacGenerator:
    def __init__(self):
        self.instructions = []
        self.temp_counter = 1
        self.label_counter = 1

    def new_temp(self):
        t = f"t{self.temp_counter}"
        self.temp_counter += 1
        return t

    def new_label(self):
        l = f"L{self.label_counter}"
        self.label_counter += 1
        return l

    def generate(self, program_node):
        self.visit(program_node)
        return self.instructions

    def emit(self, op, arg1=None, arg2=None, result=None):
        self.instructions.append(TacInstruction(op, arg1, arg2, result))

    def visit(self, node):
        method_name = f"visit_{node.__class__.__name__}"
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node):
        raise Exception(f"No visit_{node.__class__.__name__} method in TacGenerator")

    def visit_Program(self, node):
        for stmt in node.statements:
            self.visit(stmt)

    def visit_VarDecl(self, node):
        if node.initializer:
            init_val = self.visit(node.initializer)
            self.emit('=', init_val, result=node.var_name)
        # declarations without initializers do not generate TAC code
        return None

    def visit_FuncDecl(self, node):
        self.emit('func_begin', result=node.func_name)
        
        # When entering a function, the arguments are passed in. In TAC, 
        # we can assume they are already available in their parameter names.
        self.visit(node.body)
        
        # Add an implicit return at the end of function if it's void
        if node.return_type == "void":
            self.emit('return')
            
        self.emit('func_end', result=node.func_name)

    def visit_ReturnStmt(self, node):
        if node.expression:
            val = self.visit(node.expression)
            self.emit('return', arg1=val)
        else:
            self.emit('return')

    def visit_AssignStmt(self, node):
        val = self.visit(node.value)
        self.emit('=', val, result=node.var_name)
        return node.var_name

    def visit_PrintStmt(self, node):
        val = self.visit(node.expression)
        self.emit('print', arg1=val)
        return None

    def visit_InputStmt(self, node):
        self.emit('input', result=node.var_name)
        return None

    def visit_BlockStmt(self, node):
        for stmt in node.statements:
            self.visit(stmt)

    def visit_IfStmt(self, node):
        cond_val = self.visit(node.condition)
        
        if node.else_branch:
            else_label = self.new_label()
            end_label = self.new_label()
            
            self.emit('ifFalse', arg1=cond_val, result=else_label)
            self.visit(node.then_branch)
            self.emit('goto', result=end_label)
            
            self.emit('label', result=else_label)
            self.visit(node.else_branch)
            self.emit('label', result=end_label)
        else:
            else_label = self.new_label()
            self.emit('ifFalse', arg1=cond_val, result=else_label)
            self.visit(node.then_branch)
            self.emit('label', result=else_label)

    def visit_WhileStmt(self, node):
        start_label = self.new_label()
        end_label = self.new_label()
        
        self.emit('label', result=start_label)
        cond_val = self.visit(node.condition)
        self.emit('ifFalse', arg1=cond_val, result=end_label)
        
        self.visit(node.body)
        self.emit('goto', result=start_label)
        self.emit('label', result=end_label)

    def visit_ForStmt(self, node):
        # We can implement a clean 'for' statement in TAC
        # 1. Execute initialization
        if node.init:
            self.visit(node.init)
            
        start_label = self.new_label()
        end_label = self.new_label()
        
        self.emit('label', result=start_label)
        
        # 2. Check condition
        if node.condition:
            cond_val = self.visit(node.condition)
            self.emit('ifFalse', arg1=cond_val, result=end_label)
            
        # 3. Loop body
        self.visit(node.body)
        
        # 4. Post update
        if node.post:
            self.visit(node.post)
            
        self.emit('goto', result=start_label)
        self.emit('label', result=end_label)

    # Expression visitors (return temporary variable or literal)
    def visit_BinaryOp(self, node):
        left_val = self.visit(node.left)
        right_val = self.visit(node.right)
        
        temp = self.new_temp()
        self.emit(node.op, left_val, right_val, result=temp)
        return temp

    def visit_UnaryOp(self, node):
        expr_val = self.visit(node.expr)
        
        temp = self.new_temp()
        self.emit(node.op, expr_val, result=temp)
        return temp

    def visit_Literal(self, node):
        # Return literal value directly to be used as argument in TAC instructions
        # If it's a string, we return it wrapped in quotes
        if node.type == "STRING":
            return f'"{node.value}"'
        elif node.type == "CHAR":
            return f"'{node.value}'"
        elif node.type == "BOOL":
            return "true" if node.value else "false"
        return node.value

    def visit_Identifier(self, node):
        return node.name

    def visit_FuncCall(self, node):
        # Evaluate arguments
        arg_vals = [self.visit(arg) for arg in node.args]
        
        # Emit parameters
        for val in arg_vals:
            self.emit('param', arg1=val)
            
        # Call function
        # Check if the function returns void. If it returns void, result temp is None.
        # Note: In standard TAC, we can always assign to a temp or just let the caller decide.
        # Since we annotated the node with resolved_type during semantic check, we check it:
        has_return = getattr(node, "resolved_type", "void") != "void"
        
        if has_return:
            temp = self.new_temp()
            self.emit('call', arg1=node.func_name, arg2=len(arg_vals), result=temp)
            return temp
        else:
            self.emit('call', arg1=node.func_name, arg2=len(arg_vals))
            return None
