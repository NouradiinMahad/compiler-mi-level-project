class CCodeGenerator:
    def __init__(self):
        self.output = []
        self.indent_level = 0

    def indent(self):
        return "    " * self.indent_level

    def generate(self, node):
        self.output = []
        self.output.append("#include <stdio.h>")
        self.output.append("#include <stdbool.h>")
        self.output.append("")
        
        self.visit(node)
        return "\n".join(self.output)

    def visit(self, node):
        method_name = f"visit_{node.__class__.__name__}"
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node):
        raise Exception(f"No visit_{node.__class__.__name__} method in CCodeGenerator")

    def visit_Program(self, node):
        for stmt in node.statements:
            self.visit(stmt)

    def visit_VarDecl(self, node):
        c_type = self.map_type(node.type_name)
        if node.initializer:
            val = self.visit(node.initializer)
            self.output.append(f"{self.indent()}{c_type} {node.var_name} = {val};")
        else:
            self.output.append(f"{self.indent()}{c_type} {node.var_name};")

    def visit_FuncDecl(self, node):
        ret_type = self.map_type(node.return_type)
        func_name = node.func_name
        if func_name == "main":
            ret_type = "int"
            
        params = []
        for ptype, pname, _, _ in node.params:
            params.append(f"{self.map_type(ptype)} {pname}")
            
        params_str = ", ".join(params)
        self.output.append(f"{self.indent()}{ret_type} {func_name}({params_str}) {{")
        self.indent_level += 1
        
        for stmt in node.body.statements:
            self.visit(stmt)
            
        if func_name == "main":
            self.output.append(f"{self.indent()}return 0;")
            
        self.indent_level -= 1
        self.output.append(f"{self.indent()}}}")
        self.output.append("")

    def visit_ReturnStmt(self, node):
        if node.expression:
            val = self.visit(node.expression)
            self.output.append(f"{self.indent()}return {val};")
        else:
            self.output.append(f"{self.indent()}return;")

    def visit_AssignStmt(self, node):
        val = self.visit(node.value)
        self.output.append(f"{self.indent()}{node.var_name} = {val};")

    def visit_PrintStmt(self, node):
        expr_type = getattr(node.expression, "resolved_type", "int")
        val = self.visit(node.expression)
        
        if expr_type == "int":
            self.output.append(f"{self.indent()}printf(\"%d\\n\", {val});")
        elif expr_type == "float":
            self.output.append(f"{self.indent()}printf(\"%f\\n\", {val});")
        elif expr_type == "string":
            self.output.append(f"{self.indent()}printf(\"%s\\n\", {val});")
        elif expr_type == "char":
            self.output.append(f"{self.indent()}printf(\"%c\\n\", {val});")
        elif expr_type == "bool":
            self.output.append(f"{self.indent()}printf(\"%s\\n\", {val} ? \"true\" : \"false\");")
        else:
            self.output.append(f"{self.indent()}printf(\"%d\\n\", {val});")

    def visit_InputStmt(self, node):
        self.output.append(f"{self.indent()}scanf(\"%d\", &{node.var_name});")

    def visit_BlockStmt(self, node):
        self.output.append(f"{self.indent()}{{")
        self.indent_level += 1
        for stmt in node.statements:
            self.visit(stmt)
        self.indent_level -= 1
        self.output.append(f"{self.indent()}}}")

    def visit_IfStmt(self, node):
        cond = self.visit(node.condition)
        self.output.append(f"{self.indent()}if ({cond})")
        self.visit(node.then_branch)
        if node.else_branch:
            self.output.append(f"{self.indent()}else")
            self.visit(node.else_branch)

    def visit_WhileStmt(self, node):
        cond = self.visit(node.condition)
        self.output.append(f"{self.indent()}while ({cond})")
        self.visit(node.body)

    def visit_ForStmt(self, node):
        init_str = ""
        if node.init:
            old_output = self.output
            self.output = []
            self.visit(node.init)
            init_str = "".join(self.output).strip().rstrip(';')
            self.output = old_output
            
        cond_str = ""
        if node.condition:
            cond_str = self.visit(node.condition)
            
        post_str = ""
        if node.post:
            old_output = self.output
            self.output = []
            self.visit(node.post)
            post_str = "".join(self.output).strip().rstrip(';')
            self.output = old_output
            
        self.output.append(f"{self.indent()}for ({init_str}; {cond_str}; {post_str})")
        self.visit(node.body)

    def visit_BinaryOp(self, node):
        l = self.visit(node.left)
        r = self.visit(node.right)
        return f"({l} {node.op} {r})"

    def visit_UnaryOp(self, node):
        e = self.visit(node.expr)
        return f"({node.op}{e})"

    def visit_Literal(self, node):
        if node.type == "STRING":
            return f'"{node.value}"'
        elif node.type == "CHAR":
            return f"'{node.value}'"
        elif node.type == "BOOL":
            return "true" if node.value else "false"
        return str(node.value)

    def visit_Identifier(self, node):
        return node.name

    def visit_FuncCall(self, node):
        args = [self.visit(arg) for arg in node.args]
        return f"{node.func_name}({', '.join(args)})"

    def map_type(self, t):
        mapping = {
            "int": "int",
            "float": "float",
            "char": "char",
            "bool": "bool",
            "string": "char*",
            "void": "void"
        }
        return mapping.get(t, "int")


class PythonCodeGenerator:
    def __init__(self):
        self.output = []
        self.indent_level = 0

    def indent(self):
        return "    " * self.indent_level

    def generate(self, node):
        self.output = []
        self.visit(node)
        
        has_main = False
        for stmt in node.statements:
            if stmt.__class__.__name__ == "FuncDecl" and stmt.func_name == "main":
                has_main = True
                break
        if has_main:
            self.output.append("")
            self.output.append("if __name__ == '__main__':")
            self.output.append("    main()")
            
        return "\n".join(self.output)

    def visit(self, node):
        method_name = f"visit_{node.__class__.__name__}"
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node):
        raise Exception(f"No visit_{node.__class__.__name__} method in PythonCodeGenerator")

    def visit_Program(self, node):
        for stmt in node.statements:
            self.visit(stmt)

    def visit_VarDecl(self, node):
        if node.initializer:
            val = self.visit(node.initializer)
            self.output.append(f"{self.indent()}{node.var_name} = {val}")
        else:
            self.output.append(f"{self.indent()}{node.var_name} = None")

    def visit_FuncDecl(self, node):
        func_name = node.func_name
        params = [p[1] for p in node.params]
        params_str = ", ".join(params)
        
        self.output.append(f"{self.indent()}def {func_name}({params_str}):")
        self.indent_level += 1
        
        if not node.body.statements:
            self.output.append(f"{self.indent()}pass")
        else:
            for stmt in node.body.statements:
                self.visit(stmt)
                
        self.indent_level -= 1
        self.output.append("")

    def visit_ReturnStmt(self, node):
        if node.expression:
            val = self.visit(node.expression)
            self.output.append(f"{self.indent()}return {val}")
        else:
            self.output.append(f"{self.indent()}return")

    def visit_AssignStmt(self, node):
        val = self.visit(node.value)
        self.output.append(f"{self.indent()}{node.var_name} = {val}")

    def visit_PrintStmt(self, node):
        val = self.visit(node.expression)
        expr_type = getattr(node.expression, "resolved_type", "int")
        if expr_type == "bool":
            self.output.append(f"{self.indent()}print('true' if {val} else 'false')")
        else:
            self.output.append(f"{self.indent()}print({val})")

    def visit_InputStmt(self, node):
        self.output.append(f"{self.indent()}{node.var_name} = int(input())")

    def visit_BlockStmt(self, node):
        for stmt in node.statements:
            self.visit(stmt)

    def visit_IfStmt(self, node):
        cond = self.visit(node.condition)
        self.output.append(f"{self.indent()}if {cond}:")
        
        self.indent_level += 1
        if node.then_branch.__class__.__name__ == "BlockStmt" and not node.then_branch.statements:
            self.output.append(f"{self.indent()}pass")
        else:
            self.visit(node.then_branch)
        self.indent_level -= 1
        
        if node.else_branch:
            self.output.append(f"{self.indent()}else:")
            self.indent_level += 1
            if node.else_branch.__class__.__name__ == "BlockStmt" and not node.else_branch.statements:
                self.output.append(f"{self.indent()}pass")
            else:
                self.visit(node.else_branch)
            self.indent_level -= 1

    def visit_WhileStmt(self, node):
        cond = self.visit(node.condition)
        self.output.append(f"{self.indent()}while {cond}:")
        self.indent_level += 1
        if node.body.__class__.__name__ == "BlockStmt" and not node.body.statements:
            self.output.append(f"{self.indent()}pass")
        else:
            self.visit(node.body)
        self.indent_level -= 1

    def visit_ForStmt(self, node):
        if node.init:
            self.visit(node.init)
        
        cond_str = self.visit(node.condition) if node.condition else "True"
        self.output.append(f"{self.indent()}while {cond_str}:")
        self.indent_level += 1
        
        self.visit(node.body)
        
        if node.post:
            self.visit(node.post)
            
        self.indent_level -= 1

    def visit_BinaryOp(self, node):
        l = self.visit(node.left)
        r = self.visit(node.right)
        op = node.op
        if op == "&&": op = "and"
        elif op == "||": op = "or"
        return f"({l} {op} {r})"

    def visit_UnaryOp(self, node):
        e = self.visit(node.expr)
        op = node.op
        if op == "!": op = "not "
        return f"({op}{e})"

    def visit_Literal(self, node):
        if node.type == "STRING":
            return f'"{node.value}"'
        elif node.type == "CHAR":
            return f"'{node.value}'"
        elif node.type == "BOOL":
            return "True" if node.value else "False"
        return str(node.value)

    def visit_Identifier(self, node):
        return node.name

    def visit_FuncCall(self, node):
        args = [self.visit(arg) for arg in node.args]
        return f"{node.func_name}({', '.join(args)})"
