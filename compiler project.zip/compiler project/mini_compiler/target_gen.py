class AssemblyInstruction:
    def __init__(self, op, arg1=None, arg2=None):
        self.op = op
        self.arg1 = arg1
        self.arg2 = arg2

    def __repr__(self):
        if self.arg2 is not None:
            return f"  {self.op:<6} {self.arg1}, {self.arg2}"
        elif self.arg1 is not None:
            if self.op == 'LABEL':
                return f"{self.arg1}:"
            return f"  {self.op:<6} {self.arg1}"
        else:
            return f"  {self.op}"


class TargetGenerator:
    def __init__(self):
        self.assembly = []
        # Register tracker: register_name -> variable_currently_held
        self.registers = {f"R{i}": None for i in range(1, 6)}  # R1, R2, R3, R4, R5
        self.last_used_reg = None

    def emit(self, op, arg1=None, arg2=None):
        self.assembly.append(AssemblyInstruction(op, arg1, arg2))

    def get_register_for(self, var):
        # 1. Check if var is already in a register
        for reg, val in self.registers.items():
            if val == var:
                return reg
        return None

    def allocate_register(self, var_to_store):
        # 1. Look for an empty register
        for reg, val in self.registers.items():
            if val is None:
                self.registers[reg] = var_to_store
                return reg
                
        # 2. Spill register (choose one to overwrite, simple FIFO/Round-Robin)
        # For simplicity, we just free the first register that isn't holding EAX/EBP/ESP
        # and clear its association.
        spill_reg = "R1"
        self.registers[spill_reg] = var_to_store
        return spill_reg

    def free_register_holding(self, var):
        for reg, val in self.registers.items():
            if val == var:
                self.registers[reg] = None

    def clear_registers(self):
        # Reset all registers (e.g., at basic block boundaries like labels/jumps)
        for reg in self.registers:
            self.registers[reg] = None

    def generate(self, tac_instructions):
        self.assembly = []
        self.clear_registers()

        # Let's map TAC operators to assembly instructions
        op_map = {
            '+': 'ADD',
            '-': 'SUB',
            '*': 'MUL',
            '/': 'DIV',
            '%': 'MOD',
            '<': 'CMP_LT',
            '>': 'CMP_GT',
            '<=': 'CMP_LE',
            '>=': 'CMP_GE',
            '==': 'CMP_EQ',
            '!=': 'CMP_NE',
            '&&': 'AND',
            '||': 'OR'
        }

        i = 0
        while i < len(tac_instructions):
            inst = tac_instructions[i]
            op = inst.op
            arg1 = inst.arg1
            arg2 = inst.arg2
            result = inst.result

            if op == 'label':
                self.clear_registers()
                self.emit('LABEL', result)
                
            elif op == 'func_begin':
                self.clear_registers()
                self.emit('LABEL', result)
                self.emit('PUSH', 'EBP')
                self.emit('MOV', 'EBP', 'ESP')
                
            elif op == 'func_end':
                self.emit('MOV', 'ESP', 'EBP')
                self.emit('POP', 'EBP')
                self.emit('RET')
                self.clear_registers()

            elif op == 'goto':
                self.clear_registers()
                self.emit('JMP', result)

            elif op == 'ifFalse':
                # Check condition
                reg = self.get_register_for(arg1)
                if not reg:
                    reg = self.allocate_register(arg1)
                    self.emit('MOV', reg, arg1)
                
                self.emit('CMP', reg, '0')
                self.emit('JE', result)
                self.clear_registers()

            elif op == '=':
                # Copy or assignment
                reg = self.get_register_for(arg1)
                if reg:
                    self.emit('MOV', result, reg)
                    # Now result is also associated with this register
                    self.registers[reg] = result
                else:
                    reg = self.allocate_register(arg1)
                    self.emit('MOV', reg, arg1)
                    self.emit('MOV', result, reg)
                    self.registers[reg] = result

            elif op == '-' and arg2 is None:
                # Unary minus (negation)
                reg = self.get_register_for(arg1)
                if reg:
                    self.emit('NEG', reg)
                    self.registers[reg] = result
                else:
                    reg = self.allocate_register(result)
                    self.emit('MOV', reg, arg1)
                    self.emit('NEG', reg)
                    self.registers[reg] = result

            elif op in op_map:
                # Binary operations
                asm_op = op_map[op]
                
                # Check if arg1 is in register
                reg = self.get_register_for(arg1)
                if reg:
                    # Perform op directly on register
                    self.emit(asm_op, reg, arg2)
                    # Associate register with the new result
                    self.registers[reg] = result
                else:
                    reg = self.allocate_register(result)
                    self.emit('MOV', reg, arg1)
                    self.emit(asm_op, reg, arg2)
                    self.registers[reg] = result

            elif op == '!':
                # Unary NOT
                reg = self.get_register_for(arg1)
                if reg:
                    self.emit('NOT', reg)
                    self.registers[reg] = result
                else:
                    reg = self.allocate_register(result)
                    self.emit('MOV', reg, arg1)
                    self.emit('NOT', reg)
                    self.registers[reg] = result

            elif op == 'print':
                reg = self.get_register_for(arg1)
                if reg:
                    self.emit('PUSH', reg)
                else:
                    self.emit('PUSH', arg1)
                self.emit('CALL', 'print')
                self.emit('ADD', 'ESP', '4')

            elif op == 'input':
                self.emit('CALL', 'input')
                self.emit('MOV', result, 'EAX')
                # result is now in EAX, not in standard registers

            elif op == 'param':
                reg = self.get_register_for(arg1)
                if reg:
                    self.emit('PUSH', reg)
                else:
                    self.emit('PUSH', arg1)

            elif op == 'call':
                self.emit('CALL', arg1)
                # Stack cleanup
                num_args = int(arg2) if arg2 else 0
                if num_args > 0:
                    self.emit('ADD', 'ESP', str(num_args * 4))
                
                if result:
                    self.emit('MOV', result, 'EAX')
                    # Register association
                    reg = self.allocate_register(result)
                    self.emit('MOV', reg, 'EAX')
                    self.registers[reg] = result

            elif op == 'return':
                if arg1 is not None:
                    reg = self.get_register_for(arg1)
                    if reg:
                        self.emit('MOV', 'EAX', reg)
                    else:
                        self.emit('MOV', 'EAX', arg1)
                # jump or emit epilogue instructions
                # In simple assembly, we can just do EBP/ESP cleanup and RET
                self.emit('MOV', 'ESP', 'EBP')
                self.emit('POP', 'EBP')
                self.emit('RET')

            i += 1

        return self.assembly
