import re

class Token:
    def __init__(self, type_, lexeme, line, column):
        self.type = type_
        self.lexeme = lexeme
        self.line = line
        self.column = column

    def to_dict(self):
        return {
            "type": self.type,
            "lexeme": self.lexeme,
            "line": self.line,
            "column": self.column
        }

    def __repr__(self):
        return f"Token({self.type}, '{self.lexeme}', {self.line}:{self.column})"


class LexicalError(Exception):
    def __init__(self, message, line, column):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(f"Lexical Error at line {line}, column {column}: {message}")


class Lexer:
    KEYWORDS = {
        'int', 'float', 'char', 'bool', 'string', 'void',
        'if', 'else', 'while', 'for', 'print', 'input',
        'func', 'return'
    }

    def __init__(self, source):
        self.source = source
        self.pos = 0
        self.line = 1
        self.col = 1
        self.length = len(source)
        self.errors = []

    def peek(self, offset=0):
        if self.pos + offset >= self.length:
            return None
        return self.source[self.pos + offset]

    def advance(self):
        if self.pos >= self.length:
            return None
        char = self.source[self.pos]
        self.pos += 1
        if char == '\n':
            self.line += 1
            self.col = 1
        else:
            self.col += 1
        return char

    def skip_whitespace_and_comments(self):
        while self.pos < self.length:
            char = self.peek()
            if char in (' ', '\t', '\r', '\n'):
                self.advance()
            elif char == '/' and self.peek(1) == '/':
                # Single-line comment
                self.advance() # /
                self.advance() # /
                while self.pos < self.length and self.peek() != '\n':
                    self.advance()
            elif char == '/' and self.peek(1) == '*':
                # Multi-line comment
                start_line, start_col = self.line, self.col
                self.advance() # /
                self.advance() # *
                closed = False
                while self.pos < self.length:
                    if self.peek() == '*' and self.peek(1) == '/':
                        self.advance() # *
                        self.advance() # /
                        closed = True
                        break
                    self.advance()
                if not closed:
                    self.errors.append(LexicalError("Unterminated multi-line comment", start_line, start_col))
            else:
                break

    def tokenize(self):
        tokens = []
        while self.pos < self.length:
            self.skip_whitespace_and_comments()
            if self.pos >= self.length:
                break

            char = self.peek()
            start_line = self.line
            start_col = self.col

            # Identifier or Keyword
            if char.isalpha() or char == '_':
                lexeme = []
                while self.pos < self.length and (self.peek().isalnum() or self.peek() == '_'):
                    lexeme.append(self.advance())
                lexeme_str = "".join(lexeme)

                if lexeme_str in self.KEYWORDS:
                    tokens.append(Token("KEYWORD", lexeme_str, start_line, start_col))
                elif lexeme_str in ('true', 'false'):
                    tokens.append(Token("BOOL_LIT", lexeme_str, start_line, start_col))
                else:
                    tokens.append(Token("IDENTIFIER", lexeme_str, start_line, start_col))
                continue

            # Numbers (Integer and Floating-point)
            if char.isdigit():
                lexeme = []
                while self.pos < self.length and self.peek().isdigit():
                    lexeme.append(self.advance())
                
                # Check for decimal point
                if self.peek() == '.' and self.peek(1) is not None and self.peek(1).isdigit():
                    lexeme.append(self.advance()) # '.'
                    while self.pos < self.length and self.peek().isdigit():
                        lexeme.append(self.advance())
                    tokens.append(Token("FLOAT_LIT", "".join(lexeme), start_line, start_col))
                else:
                    tokens.append(Token("INT_LIT", "".join(lexeme), start_line, start_col))
                continue

            # String Literals
            if char == '"':
                self.advance() # Open quote
                lexeme = []
                closed = False
                while self.pos < self.length:
                    curr = self.peek()
                    if curr == '"':
                        self.advance() # Close quote
                        closed = True
                        break
                    elif curr == '\n':
                        # Multiline string literals not allowed in this simple syntax
                        break
                    else:
                        lexeme.append(self.advance())
                
                if closed:
                    tokens.append(Token("STRING_LIT", "".join(lexeme), start_line, start_col))
                else:
                    self.errors.append(LexicalError("Unterminated string literal", start_line, start_col))
                continue

            # Character Literals
            if char == "'":
                self.advance() # Open quote
                lexeme = []
                closed = False
                if self.pos < self.length and self.peek() != "'":
                    lexeme.append(self.advance())
                if self.pos < self.length and self.peek() == "'":
                    self.advance() # Close quote
                    closed = True
                
                if closed and len(lexeme) == 1:
                    tokens.append(Token("CHAR_LIT", lexeme[0], start_line, start_col))
                else:
                    self.errors.append(LexicalError("Invalid or unterminated character literal", start_line, start_col))
                    # advance past whatever is there to avoid infinite loop
                    if self.peek() == "'":
                        self.advance()
                continue

            # Two-character Operators
            two_char_ops = {
                '==': 'EQ',
                '!=': 'NE',
                '<=': 'LE',
                '>=': 'GE',
                '&&': 'AND',
                '||': 'OR'
            }
            if self.pos + 1 < self.length:
                potential_op = char + self.peek(1)
                if potential_op in two_char_ops:
                    self.advance() # First char
                    self.advance() # Second char
                    tokens.append(Token("OPERATOR", potential_op, start_line, start_col))
                    continue

            # One-character Operators & Delimiters
            one_char_ops = {'+', '-', '*', '/', '%', '=', '<', '>', '!'}
            delimiters = {';', ',', '(', ')', '{', '}', '[', ']'}

            if char in one_char_ops:
                self.advance()
                tokens.append(Token("OPERATOR", char, start_line, start_col))
                continue

            if char in delimiters:
                self.advance()
                tokens.append(Token("DELIMITER", char, start_line, start_col))
                continue

            # Invalid Token
            self.advance()
            self.errors.append(LexicalError(f"Unexpected character '{char}'", start_line, start_col))

        tokens.append(Token("EOF", "EOF", self.line, self.col))
        return tokens, self.errors
