import subprocess
import tempfile
import os
import sys

# Wrapper points to the batch file we created
COMPILER = "my_compiler.bat"
INPUT_FILE = "test.src"
OUTPUT_FILE = "out.py"  # Compiles to out.py for zero-dependency portability

# Test program (C-like grammar subset)
source_code = """
func void main() {
    print(2 + 3);
}
"""

expected_output = "5"


def compile_program():
    with open(INPUT_FILE, "w") as f:
        f.write(source_code)

    # Invoke the batch file wrapper
    result = subprocess.run(
        [COMPILER, INPUT_FILE, OUTPUT_FILE],
        shell=True,  # Windows shell execution for .bat files
        capture_output=True,
        text=True,
    )

    return result


def run_program():
    if OUTPUT_FILE.endswith(".py"):
        result = subprocess.run(
            ["python", OUTPUT_FILE],
            capture_output=True,
            text=True,
        )
    elif OUTPUT_FILE.endswith(".exe"):
        result = subprocess.run(
            [OUTPUT_FILE],
            capture_output=True,
            text=True,
        )
    else:
        raise RuntimeError("Unknown output type")

    return result.stdout.strip()


def main():
    # Make sure we clean up previous output file
    if os.path.exists(OUTPUT_FILE):
        os.remove(OUTPUT_FILE)
        
    compile_result = compile_program()

    # If compilation fails, print stderr details
    if compile_result.returncode != 0:
        print("[FAIL] Compiler failed")
        print("STDOUT:", compile_result.stdout)
        print("STDERR:", compile_result.stderr)
        return

    print("[SUCCESS] Compilation succeeded")

    output = run_program()

    print("Program output :", output)
    print("Expected output:", expected_output)

    if output == expected_output:
        print("[SUCCESS] TEST PASSED")
    else:
        print("[FAIL] TEST FAILED")

    # Clean up test files
    if os.path.exists(INPUT_FILE):
        os.remove(INPUT_FILE)
    if os.path.exists(OUTPUT_FILE):
        os.remove(OUTPUT_FILE)


if __name__ == "__main__":
    main()
