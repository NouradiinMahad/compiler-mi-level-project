// Presets Configuration
const PRESETS = {
    full: `// A mid-level compiler demo program (functions and recursion)
func int fibonacci(int n) {
    if (n <= 1) {
        return n;
    }
    int a = fibonacci(n - 1);
    int b = fibonacci(n - 2);
    return a + b;
}

func void main() {
    int x = 6;
    int result = fibonacci(x);
    print(result);
}`,
    syntax: `// Syntax error: Mismatched parentheses in condition
func void main() {
    int x = 10;
    if (x > 5 {
        print(x);
    }
}`,
    semantic: `// Semantic error: Type mismatch and duplicate declaration
func void main() {
    int a = 10;
    float a = 5.5; // Duplicate declaration error!
    
    string msg = "Hello";
    int b = a + msg; // Type mismatch error!
}`,
    optimize: `// Optimization demo: watch the TAC transform!
func void main() {
    // 1. Constant folding (5 * 4 is folded to 20)
    int a = 5 * 4; 
    
    // 2. Constant propagation (a is replaced by 20, then 20 + 10 folded to 30)
    int b = a + 10; 
    
    // 3. Common Subexpression Elimination (CSE)
    int x = b * 2;
    int y = b * 2; // Reused calculation: y = x
    
    // 4. Dead Code Elimination (z is never read, t-temps eliminated)
    int z = 100;
    
    print(x + y);
}`
};

// DOM Elements
const codeInput = document.getElementById('codeInput');
const lineNumbers = document.getElementById('lineNumbers');
const compileBtn = document.getElementById('compileBtn');
const compileStatus = document.getElementById('compileStatus');
const tokensList = document.getElementById('tokensList');
const astTree = document.getElementById('astTree');
const symbolsList = document.getElementById('symbolsList');
const semanticStatusCard = document.getElementById('semanticStatusCard');
const semanticStatusIcon = document.getElementById('semanticStatusIcon');
const semanticStatusTitle = document.getElementById('semanticStatusTitle');
const semanticStatusDesc = document.getElementById('semanticStatusDesc');
const semanticErrorsList = document.getElementById('semanticErrorsList');
const tacView = document.getElementById('tacView');
const optTacView = document.getElementById('optTacView');
const assemblyView = document.getElementById('assemblyView');
const executionView = document.getElementById('executionView');
const notificationContainer = document.getElementById('notificationContainer');

// Editor Line Number Synchronization
function updateLineNumbers() {
    const lines = codeInput.value.split('\n');
    const lineCount = Math.max(lines.length, 1);
    let numbers = '';
    for (let i = 1; i <= lineCount; i++) {
        numbers += i + '<br>';
    }
    lineNumbers.innerHTML = numbers;
}

codeInput.addEventListener('input', updateLineNumbers);
codeInput.addEventListener('scroll', () => {
    lineNumbers.scrollTop = codeInput.scrollTop;
});

// Preset buttons selection removed

// Tabs Switching
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        
        btn.classList.add('active');
        const tabId = btn.getAttribute('data-tab') + 'Tab';
        document.getElementById(tabId).classList.add('active');
    });
});

// Notifications
function showNotification(message, type = 'success') {
    const notif = document.createElement('div');
    notif.className = `notification ${type}`;
    
    let icon = '✓';
    if (type === 'error') icon = '✕';
    
    notif.innerHTML = `<span style="font-weight:bold; font-size:1.1rem">${icon}</span> <span>${message}</span>`;
    notificationContainer.appendChild(notif);
    
    setTimeout(() => {
        notif.style.animation = 'none';
        notif.offsetHeight; // trigger reflow
        notif.style.opacity = '0';
        notif.style.transform = 'translateY(10px)';
        notif.style.transition = 'all 0.3s ease';
        setTimeout(() => notif.remove(), 300);
    }, 3000);
}

// AST Tree Expand/Collapse
document.getElementById('expandAst').addEventListener('click', () => {
    document.querySelectorAll('.ast-node-children').forEach(el => el.classList.remove('collapsed'));
    document.querySelectorAll('.ast-toggle').forEach(el => el.textContent = '▼');
});

document.getElementById('collapseAst').addEventListener('click', () => {
    document.querySelectorAll('.ast-node-children').forEach(el => el.classList.add('collapsed'));
    document.querySelectorAll('.ast-toggle').forEach(el => el.textContent = '▶');
});

// AST Renderer (Recursively build DOM elements)
function createAstDOM(node) {
    if (!node || typeof node !== 'object') {
        const leaf = document.createElement('div');
        leaf.className = 'ast-node-val';
        leaf.textContent = String(node);
        return leaf;
    }

    const wrapper = document.createElement('div');
    wrapper.className = 'ast-node';

    const header = document.createElement('div');
    header.className = 'ast-node-header';

    const nodeType = document.createElement('span');
    nodeType.className = 'ast-node-type';
    nodeType.textContent = node.node_type || 'Node';

    header.appendChild(nodeType);

    // Node contents display
    const labelMapping = {
        'VarDecl': () => ` [type: ${node.type_name}, name: ${node.var_name}]`,
        'AssignStmt': () => ` [var: ${node.var_name}]`,
        'PrintStmt': () => '',
        'InputStmt': () => ` [var: ${node.var_name}]`,
        'FuncDecl': () => ` [name: ${node.func_name}, returns: ${node.return_type}]`,
        'FuncCall': () => ` [func: ${node.func_name}]`,
        'Identifier': () => `: "${node.name}"`,
        'Literal': () => `: ${JSON.stringify(node.value)} (${node.type})`,
        'BinaryOp': () => ` [op: "${node.op}"]`,
        'UnaryOp': () => ` [op: "${node.op}"]`,
        'ReturnStmt': () => ''
    };

    if (labelMapping[node.node_type]) {
        const extraText = labelMapping[node.node_type]();
        if (extraText) {
            const extra = document.createElement('span');
            extra.className = 'ast-node-val';
            extra.textContent = extraText;
            header.appendChild(extra);
        }
    }

    // Children processing
    const childKeys = ['initializer', 'body', 'statements', 'expression', 'condition', 'then_branch', 'else_branch', 'init', 'post', 'left', 'right', 'expr', 'args'];
    const childrenList = [];

    childKeys.forEach(key => {
        if (node[key] !== undefined && node[key] !== null) {
            if (Array.isArray(node[key])) {
                node[key].forEach((c, idx) => {
                    childrenList.push({ label: `${key}[${idx}]`, value: c });
                });
            } else {
                childrenList.push({ label: key, value: node[key] });
            }
        }
    });

    if (childrenList.length > 0) {
        const toggle = document.createElement('span');
        toggle.className = 'ast-toggle';
        toggle.textContent = '▼';
        header.insertBefore(toggle, header.firstChild);

        const childrenContainer = document.createElement('div');
        childrenContainer.className = 'ast-node-children';

        childrenList.forEach(child => {
            const childRow = document.createElement('div');
            childRow.className = 'ast-node';
            
            const branchLabel = document.createElement('span');
            branchLabel.style.color = '#9ca3af';
            branchLabel.style.fontSize = '0.75rem';
            branchLabel.style.marginRight = '0.5rem';
            branchLabel.textContent = child.label + ':';
            
            childRow.appendChild(branchLabel);
            childRow.appendChild(createAstDOM(child.value));
            childrenContainer.appendChild(childRow);
        });

        wrapper.appendChild(header);
        wrapper.appendChild(childrenContainer);

        header.addEventListener('click', (e) => {
            e.stopPropagation();
            const isCollapsed = childrenContainer.classList.toggle('collapsed');
            toggle.textContent = isCollapsed ? '▶' : '▼';
        });
    } else {
        wrapper.appendChild(header);
    }

    return wrapper;
}

// Call Compiler API
async function runCompiler() {
    const code = codeInput.value;
    compileBtn.disabled = true;
    compileBtn.innerHTML = 'Running...';
    
    try {
        const response = await fetch('/compile', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ code })
        });
        
        const data = await response.json();
        
        if (data.success) {
            updateUIForSuccess(data);
        } else {
            updateUIForFailure(data);
        }
    } catch (err) {
        console.error(err);
        showNotification('Failed to connect to compiler server', 'error');
        compileStatus.textContent = 'Offline';
        compileStatus.className = 'compile-status error';
    } finally {
        compileBtn.disabled = false;
        compileBtn.innerHTML = '<span class="btn-glow"></span>Run Compiler Engine';
    }
}

function updateUIForSuccess(data) {
    // 1. Set status badge
    compileStatus.textContent = 'SUCCESSFUL';
    compileStatus.className = 'compile-status success';
    showNotification('Code compiled successfully!', 'success');

    // 2. Render Tokens
    tokensList.innerHTML = '';
    data.tokens.forEach(tok => {
        const row = document.createElement('div');
        row.className = 'token-row';
        
        const badgeType = tok.type.toLowerCase();
        
        row.innerHTML = `
            <div class="coord">${tok.line}:${tok.column}</div>
            <div><span class="badge ${badgeType}">${tok.type}</span></div>
            <div class="lexeme">${escapeHtml(tok.lexeme)}</div>
        `;
        tokensList.appendChild(row);
    });

    // 3. Render AST
    astTree.innerHTML = '';
    astTree.appendChild(createAstDOM(data.ast));

    // 4. Render Symbol Table
    symbolsList.innerHTML = '';
    data.symbols.forEach(sym => {
        const row = document.createElement('tr');
        
        const params = sym.params 
            ? `(${sym.params.map(p => `${p.type} ${p.name}`).join(', ')})` 
            : '';
            
        row.innerHTML = `
            <td style="font-weight:bold; color:#f3f4f6">${sym.name}</td>
            <td><span class="category-badge ${sym.category}">${sym.category}</span></td>
            <td style="color:#06b6d4">${sym.type}${params}</td>
            <td style="text-align:center">${sym.scope_level}</td>
            <td style="color:#6b7280">${sym.line}:${sym.column}</td>
        `;
        symbolsList.appendChild(row);
    });
    if (data.symbols.length === 0) {
        symbolsList.innerHTML = `<tr><td colspan="5" class="empty-state">No symbols declared.</td></tr>`;
    }

    // 5. Render Semantic Card
    semanticStatusCard.className = 'semantic-status-card verified';
    semanticStatusIcon.textContent = '✓';
    semanticStatusTitle.textContent = 'Semantics Verified';
    semanticStatusDesc.textContent = 'All semantic checks passed (types are safe, functions signatures match, variables are declared).';
    semanticErrorsList.style.display = 'none';

    // 6. Render TAC
    tacView.textContent = data.tac.join('\n') || '// Empty program';
    optTacView.textContent = data.optimized_tac.join('\n') || '// Empty program';

    // 7. Render Assembly
    assemblyView.textContent = data.assembly.join('\n') || '; Empty program';

    // 8. Render Execution Output
    executionView.textContent = data.execution || '// Program finished with no prints';
}

function updateUIForFailure(data) {
    // 1. Set status badge
    compileStatus.textContent = 'FAILED';
    compileStatus.className = 'compile-status error';
    showNotification(`Compilation failed in ${data.stage}`, 'error');

    // 2. Load whatever stages succeeded
    // Tokens
    if (data.tokens) {
        tokensList.innerHTML = '';
        data.tokens.forEach(tok => {
            const row = document.createElement('div');
            row.className = 'token-row';
            const badgeType = tok.type.toLowerCase();
            row.innerHTML = `
                <div class="coord">${tok.line}:${tok.column}</div>
                <div><span class="badge ${badgeType}">${tok.type}</span></div>
                <div class="lexeme">${escapeHtml(tok.lexeme)}</div>
            `;
            tokensList.appendChild(row);
        });
    } else {
        tokensList.innerHTML = `<div class="empty-state">Lexical phase failed completely.</div>`;
    }

    // AST
    if (data.ast) {
        astTree.innerHTML = '';
        astTree.appendChild(createAstDOM(data.ast));
    } else {
        astTree.innerHTML = `<div class="empty-state">Parser stage not reached/failed.</div>`;
    }

    // Symbols
    if (data.symbols) {
        symbolsList.innerHTML = '';
        data.symbols.forEach(sym => {
            const row = document.createElement('tr');
            const params = sym.params ? `(${sym.params.map(p => `${p.type} ${p.name}`).join(', ')})` : '';
            row.innerHTML = `
                <td style="font-weight:bold; color:#f3f4f6">${sym.name}</td>
                <td><span class="category-badge ${sym.category}">${sym.category}</span></td>
                <td style="color:#06b6d4">${sym.type}${params}</td>
                <td style="text-align:center">${sym.scope_level}</td>
                <td style="color:#6b7280">${sym.line}:${sym.column}</td>
            `;
            symbolsList.appendChild(row);
        });
    } else {
        symbolsList.innerHTML = `<tr><td colspan="5" class="empty-state">Symbol table failed to populate.</td></tr>`;
    }

    // 3. Render Semantic errors card
    semanticStatusCard.className = 'semantic-status-card error';
    semanticStatusIcon.textContent = '✕';
    semanticStatusTitle.textContent = `${data.stage} Failed`;
    semanticStatusDesc.textContent = 'See the error descriptions below for line coordinates:';
    
    semanticErrorsList.innerHTML = '';
    data.errors.forEach(err => {
        const item = document.createElement('div');
        item.className = 'semantic-error-item';
        item.innerHTML = `
            <span class="error-msg">${escapeHtml(err.message)}</span>
            <span class="error-coord">Line ${err.line}, Col ${err.column}</span>
        `;
        semanticErrorsList.appendChild(item);
    });
    semanticErrorsList.style.display = 'flex';

    // 4. Reset codegen views
    tacView.textContent = '// Not generated (Errors in source)';
    optTacView.textContent = '// Not generated (Errors in source)';
    assemblyView.textContent = '; Not generated (Errors in source)';
    executionView.textContent = '// Not executed (Errors in source)';
    
    // Switch to semantics tab to show errors automatically
    if (data.stage === 'Semantic Analysis') {
        document.querySelector('[data-tab="semantics"]').click();
    } else if (data.stage === 'Syntax Analysis') {
        document.querySelector('[data-tab="ast"]').click();
        astTree.innerHTML = `<div class="semantic-errors-list">` + data.errors.map(err => `
            <div class="semantic-error-item" style="margin-left:0">
                <span class="error-msg">${escapeHtml(err.message)}</span>
                <span class="error-coord">Line ${err.line}, Col ${err.column}</span>
            </div>`).join('') + `</div>`;
    }
}

// Helpers
function escapeHtml(text) {
    if (typeof text !== 'string') return text;
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Initialize editor on load
compileBtn.addEventListener('click', runCompiler);
window.addEventListener('load', () => {
    // Set default program
    codeInput.value = PRESETS.full;
    updateLineNumbers();
    runCompiler();
});
