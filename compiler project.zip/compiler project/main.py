import sys
import os
import json
import webbrowser
from http.server import SimpleHTTPRequestHandler
from socketserver import TCPServer

from mini_compiler.lexer import Lexer
from mini_compiler.parser import Parser
from mini_compiler.semantic import SemanticAnalyzer
from mini_compiler.tac import TacGenerator
from mini_compiler.optimizer import Optimizer
from mini_compiler.target_gen import TargetGenerator

def compile_code(code):
    # Phase 1: Lexical Analysis
    lexer = Lexer(code)
    tokens, lex_errors = lexer.tokenize()
    
    if lex_errors:
        return {
            "success": False,
            "stage": "Lexical Analysis",
            "errors": [{"line": e.line, "column": e.column, "message": e.message} for e in lex_errors],
            "tokens": [t.to_dict() for t in tokens]
        }
        
    # Phase 2: Syntax Analysis
    parser = Parser(tokens)
    ast, parse_errors = parser.parse()
    
    if parse_errors:
        return {
            "success": False,
            "stage": "Syntax Analysis",
            "errors": [{"line": e.line, "column": e.column, "message": e.message} for e in parse_errors],
            "tokens": [t.to_dict() for t in tokens]
        }
        
    # Phase 3 & 4: Symbol Table & Semantic Analysis
    analyzer = SemanticAnalyzer()
    sem_errors, symbol_table = analyzer.analyze(ast)
    
    if sem_errors:
        return {
            "success": False,
            "stage": "Semantic Analysis",
            "errors": [{"line": e.line, "column": e.column, "message": e.message} for e in sem_errors],
            "tokens": [t.to_dict() for t in tokens],
            "ast": ast.to_dict(),
            "symbols": symbol_table.get_all_symbols_dict()
        }
        
    # Phase 5: Intermediate Code Generation (TAC)
    tac_gen = TacGenerator()
    tac_instructions = tac_gen.generate(ast)
    tac_output = [str(inst) for inst in tac_instructions]
    
    # Phase 6: Code Optimization
    optimizer = Optimizer()
    optimized_instructions = optimizer.optimize(tac_instructions)
    optimized_tac_output = [str(inst) for inst in optimized_instructions]
    
    # Phase 7: Target Code Generation (Assembly)
    target_gen = TargetGenerator()
    assembly_instructions = target_gen.generate(optimized_instructions)
    assembly_output = [str(inst) for inst in assembly_instructions]
    
    # Run Compiled Program (Interpreter Execution)
    from mini_compiler.interpreter import Interpreter
    interpreter = Interpreter()
    execution_result = interpreter.execute(optimized_instructions, symbol_table)
    
    return {
        "success": True,
        "tokens": [t.to_dict() for t in tokens if t.type != "EOF"],
        "ast": ast.to_dict(),
        "symbols": symbol_table.get_all_symbols_dict(),
        "tac": tac_output,
        "optimized_tac": optimized_tac_output,
        "assembly": assembly_output,
        "execution": execution_result
    }


class CompilerRequestHandler(SimpleHTTPRequestHandler):
    def do_POST(self):
        if self.path == '/compile':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            try:
                data = json.loads(post_data.decode('utf-8'))
                code = data.get('code', '')
                
                result = compile_code(code)
                
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(json.dumps(result).encode('utf-8'))
            except Exception as e:
                self.send_response(400)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()

    def do_GET(self):
        # Serve web dashboard static files
        # Treat paths cleanly and map to the web/ folder
        clean_path = self.path.split('?')[0]
        if clean_path in ('/', '/index.html'):
            clean_path = '/web/index.html'
        elif clean_path in ('/style.css', '/app.js'):
            clean_path = f'/web{clean_path}'
            
        full_path = os.path.join(os.getcwd(), clean_path.lstrip('/'))
        
        if os.path.exists(full_path) and os.path.isfile(full_path):
            # Resolve content type
            if full_path.endswith('.html'):
                content_type = 'text/html'
            elif full_path.endswith('.css'):
                content_type = 'text/css'
            elif full_path.endswith('.js'):
                content_type = 'application/javascript'
            else:
                content_type = 'text/plain'
                
            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.end_headers()
            with open(full_path, 'rb') as f:
                self.wfile.write(f.read())
        else:
            self.send_response(404)
            self.end_headers()


def run_web_server(port=8000):
    TCPServer.allow_reuse_address = True
    with TCPServer(("", port), CompilerRequestHandler) as httpd:
        print(f"=======================================================")
        print(f"  Compiler Dashboard Server running at: http://localhost:{port}")
        print(f"  Press Ctrl+C to stop the server.")
        print(f"=======================================================")
        
        # Automatically open browser
        webbrowser.open(f"http://localhost:{port}")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server...")


def run_cli(file_path, output_path=None):
    if not os.path.exists(file_path):
        print(f"Error: File not found at '{file_path}'", file=sys.stderr)
        sys.exit(1)
        
    with open(file_path, 'r', encoding='utf-8') as f:
        code = f.read()

    # Pre-check compilation stages to report precise errors to stderr for tests
    lexer = Lexer(code)
    tokens, lex_errors = lexer.tokenize()
    if lex_errors:
        for err in lex_errors:
            print(f"Lexical Error at line {err.line}, Column {err.column}: {err.message}", file=sys.stderr)
        sys.exit(1)

    parser = Parser(tokens)
    ast, parse_errors = parser.parse()
    if parse_errors:
        for err in parse_errors:
            print(f"Syntax Error at line {err.line}, Column {err.column}: {err.message}", file=sys.stderr)
        sys.exit(1)

    analyzer = SemanticAnalyzer()
    sem_errors, symbol_table = analyzer.analyze(ast)
    if sem_errors:
        for err in sem_errors:
            print(f"Semantic Error at line {err.line}, Column {err.column}: {err.message}", file=sys.stderr)
        sys.exit(1)

    if output_path:
        ext = os.path.splitext(output_path)[1].lower()
        if ext == ".py":
            from mini_compiler.codegen import PythonCodeGenerator
            codegen = PythonCodeGenerator()
            py_code = codegen.generate(ast)
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(py_code)
            print(f"Generated Python code in {output_path}")
            sys.exit(0)
            
        elif ext == ".c":
            from mini_compiler.codegen import CCodeGenerator
            codegen = CCodeGenerator()
            c_code = codegen.generate(ast)
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(c_code)
            print(f"Generated C code in {output_path}")
            sys.exit(0)
            
        elif ext == ".exe":
            from mini_compiler.codegen import CCodeGenerator
            codegen = CCodeGenerator()
            c_code = codegen.generate(ast)
            
            temp_c = "temp_compile.c"
            with open(temp_c, "w", encoding="utf-8") as f:
                f.write(c_code)
                
            compiled = False
            import subprocess
            try:
                res = subprocess.run(["gcc", temp_c, "-o", output_path], capture_output=True, text=True)
                if res.returncode == 0:
                    compiled = True
                else:
                    print("C Compilation Error:", res.stderr, file=sys.stderr)
            except FileNotFoundError:
                try:
                    res = subprocess.run(["cl", temp_c, f"/Fe{output_path}"], capture_output=True, text=True)
                    if res.returncode == 0:
                        compiled = True
                except FileNotFoundError:
                    pass
                    
            if os.path.exists(temp_c):
                os.remove(temp_c)
            temp_obj = "temp_compile.obj"
            if os.path.exists(temp_obj):
                os.remove(temp_obj)
                
            if compiled:
                print(f"Compiled native executable to {output_path}")
                sys.exit(0)
            else:
                print("Error: No C compiler (gcc or cl) found in PATH, or C compilation failed.", file=sys.stderr)
                sys.exit(1)
        else:
            print(f"Error: Unsupported output extension '{ext}'. Use .py, .c, or .exe", file=sys.stderr)
            sys.exit(1)

    # Standard CLI prints when no output_path is provided
    result = compile_code(code)

    print(f"\n[+] Compilation SUCCESSFUL!")
    
    print("\n--- TOKENS ---")
    for t in result["tokens"]:
        print(f"  Line {t['line']}:{t['column']:<3} | {t['type']:<12} | '{t['lexeme']}'")
        
    print("\n--- SYMBOL TABLE ---")
    for s in result["symbols"]:
        params_str = "(" + ", ".join(f"{p['type']} {p['name']}" for p in s['params']) + ")" if s['params'] else ""
        print(f"  Name: {s['name']:<12} | Cat: {s['category']:<8} | Type: {s['type']}{params_str:<10} | Scope Depth: {s['scope_level']}")

    print("\n--- THREE-ADDRESS CODE (TAC) ---")
    for line in result["tac"]:
        print(f"  {line}")

    print("\n--- OPTIMIZED TAC ---")
    for line in result["optimized_tac"]:
        print(f"  {line}")

    print("\n--- TARGET CODE (ASSEMBLY) ---")
    for line in result["assembly"]:
        print(line)
        
    print("\n--- PROGRAM EXECUTION OUTPUT ---")
    print(result["execution"])


if __name__ == '__main__':
    if len(sys.argv) > 1:
        if sys.argv[1] == '--web':
            port = 8000
            if len(sys.argv) > 2:
                try:
                    port = int(sys.argv[2])
                except ValueError:
                    pass
            run_web_server(port)
        else:
            out_path = sys.argv[2] if len(sys.argv) > 2 else None
            run_cli(sys.argv[1], out_path)
    else:
        print("Usage:")
        print("  CLI: python main.py <source_file> [<output_file>]")
        print("  Web Server: python main.py --web")
        print("\nStarting web server by default...")
        run_web_server(8000)
