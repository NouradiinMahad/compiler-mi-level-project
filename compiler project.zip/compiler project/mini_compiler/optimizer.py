from .tac import TacInstruction

class Optimizer:
    def __init__(self):
        pass

    def optimize(self, instructions):
        # Run optimization passes in a loop until a fixed point is reached (no more changes)
        current = list(instructions)
        iteration = 0
        max_iterations = 10
        
        while iteration < max_iterations:
            # 1. Run local optimizations (Propagation, Folding, CSE) in basic blocks
            opt1, changed1 = self.optimize_basic_blocks(current)
            # 2. Run global Dead Code Elimination (DCE)
            opt2, changed2 = self.eliminate_dead_code(opt1)
            
            if not changed1 and not changed2:
                break
                
            current = opt2
            iteration += 1
            
        return current

    def get_basic_blocks(self, instructions):
        # Divide instructions into basic blocks
        # A basic block starts at a label, or after a jump/return, and ends at a jump/return or before a label.
        blocks = []
        current_block = []
        
        jump_ops = {'goto', 'ifFalse', 'return', 'func_end'}
        
        for inst in instructions:
            # A label or func_begin starts a new block
            if inst.op in ('label', 'func_begin'):
                if current_block:
                    blocks.append(current_block)
                current_block = [inst]
            else:
                current_block.append(inst)
                # A jump/return ends the current block
                if inst.op in jump_ops:
                    blocks.append(current_block)
                    current_block = []
                    
        if current_block:
            blocks.append(current_block)
            
        return blocks

    def is_constant(self, val):
        if val is None:
            return False
        # If it's a string, float, int, or boolean literal
        val_str = str(val)
        if val_str.startswith('"') and val_str.endswith('"'):
            return True
        if val_str.startswith("'") and val_str.endswith("'"):
            return True
        if val_str in ('true', 'false'):
            return True
        try:
            float(val_str)
            return True
        except ValueError:
            return False

    def eval_unary(self, op, arg):
        # Evaluate folded unary expression
        if op == '-':
            try:
                return -int(arg)
            except ValueError:
                return -float(arg)
        elif op == '!':
            val = True if str(arg) == 'true' else False
            return 'true' if not val else 'false'
        return None

    def eval_binary(self, op, arg1, arg2):
        # Evaluate folded binary expression
        try:
            # Convert values
            a1_is_float = '.' in str(arg1)
            a2_is_float = '.' in str(arg2)
            
            if a1_is_float or a2_is_float:
                a1 = float(arg1)
                a2 = float(arg2)
            else:
                a1 = int(arg1)
                a2 = int(arg2)
        except ValueError:
            # For booleans or strings
            a1 = arg1
            a2 = arg2
            if str(a1) in ('true', 'false'):
                a1 = True if str(a1) == 'true' else False
            if str(a2) in ('true', 'false'):
                a2 = True if str(a2) == 'true' else False

        if op == '+':
            res = a1 + a2
        elif op == '-':
            res = a1 - a2
        elif op == '*':
            res = a1 * a2
        elif op == '/':
            if a2 == 0:
                return None  # division by zero, leave unoptimized
            res = a1 / a2
        elif op == '%':
            res = a1 % a2
        elif op == '<':
            res = 'true' if a1 < a2 else 'false'
        elif op == '>':
            res = 'true' if a1 > a2 else 'false'
        elif op == '<=':
            res = 'true' if a1 <= a2 else 'false'
        elif op == '>=':
            res = 'true' if a1 >= a2 else 'false'
        elif op == '==':
            res = 'true' if a1 == a2 else 'false'
        elif op == '!=':
            res = 'true' if a1 != a2 else 'false'
        elif op == '&&':
            res = 'true' if (a1 and a2) else 'false'
        elif op == '||':
            res = 'true' if (a1 or a2) else 'false'
        else:
            return None

        # Format booleans
        if isinstance(res, bool):
            return 'true' if res else 'false'
        # Format floats/ints
        return res

    def optimize_basic_blocks(self, instructions):
        blocks = self.get_basic_blocks(instructions)
        optimized_instructions = []
        any_changed = False
        
        for block in blocks:
            constants = {}  # var -> constant_val
            copies = {}     # var -> original_var
            expr_map = {}   # (op, arg1, arg2) -> temp_var
            
            for inst in block:
                op = inst.op
                arg1 = inst.arg1
                arg2 = inst.arg2
                result = inst.result
                
                # Helper to invalidate any cache entries containing a modified variable
                def invalidate(var):
                    if var in constants:
                        del constants[var]
                    if var in copies:
                        del copies[var]
                    # Remove from copies values
                    keys_to_del = [k for k, v in copies.items() if v == var]
                    for k in keys_to_del:
                        del copies[k]
                    # Remove from expressions
                    exprs_to_del = [k for k in expr_map.keys() if k[1] == var or k[2] == var]
                    for k in exprs_to_del:
                        del expr_map[k]

                # 1. Propagate Constants/Copies to arg1 and arg2
                new_arg1 = arg1
                if arg1 in constants:
                    new_arg1 = constants[arg1]
                elif arg1 in copies:
                    new_arg1 = copies[arg1]
                    
                new_arg2 = arg2
                if arg2 in constants:
                    new_arg2 = constants[arg2]
                elif arg2 in copies:
                    new_arg2 = copies[arg2]

                if new_arg1 != arg1 or new_arg2 != arg2:
                    any_changed = True

                # 2. Check if we can fold or eliminate subexpressions
                arithmetic_ops = {'+', '-', '*', '/', '%', '<', '>', '<=', '>=', '==', '!=', '&&', '||', '!'}
                
                if op in arithmetic_ops and op != '!':  # Binary Operations
                    # Can we fold constants?
                    if self.is_constant(new_arg1) and self.is_constant(new_arg2):
                        folded = self.eval_binary(op, new_arg1, new_arg2)
                        if folded is not None:
                            # Replace with assignment: result = folded
                            optimized_instructions.append(TacInstruction('=', folded, result=result))
                            invalidate(result)
                            constants[result] = folded
                            any_changed = True
                            continue
                            
                    # Can we eliminate common subexpression?
                    expr_key = (op, new_arg1, new_arg2)
                    if expr_key in expr_map:
                        prev_result = expr_map[expr_key]
                        # Replace with assignment: result = prev_result
                        optimized_instructions.append(TacInstruction('=', prev_result, result=result))
                        invalidate(result)
                        copies[result] = prev_result
                        any_changed = True
                        continue
                    else:
                        expr_map[expr_key] = result
                        invalidate(result)
                        optimized_instructions.append(TacInstruction(op, new_arg1, new_arg2, result))
                        
                elif op == '!':  # Unary Logical Not
                    if self.is_constant(new_arg1):
                        folded = self.eval_unary(op, new_arg1)
                        if folded is not None:
                            optimized_instructions.append(TacInstruction('=', folded, result=result))
                            invalidate(result)
                            constants[result] = folded
                            any_changed = True
                            continue
                    
                    expr_key = (op, new_arg1, None)
                    if expr_key in expr_map:
                        prev_result = expr_map[expr_key]
                        optimized_instructions.append(TacInstruction('=', prev_result, result=result))
                        invalidate(result)
                        copies[result] = prev_result
                        any_changed = True
                    else:
                        expr_map[expr_key] = result
                        invalidate(result)
                        optimized_instructions.append(TacInstruction(op, new_arg1, result=result))

                elif op == '=':  # Copy Assignment
                    # If RHS is a constant
                    if self.is_constant(new_arg1):
                        invalidate(result)
                        constants[result] = new_arg1
                        optimized_instructions.append(TacInstruction('=', new_arg1, result=result))
                    else:
                        invalidate(result)
                        copies[result] = new_arg1
                        optimized_instructions.append(TacInstruction('=', new_arg1, result=result))
                        
                elif op == 'ifFalse':
                    # If the condition is a constant, we can simplify/propagate, but keep instruction for control-flow
                    optimized_instructions.append(TacInstruction(op, new_arg1, result=result))
                    
                elif op == 'print':
                    optimized_instructions.append(TacInstruction(op, new_arg1))
                    
                elif op == 'param':
                    optimized_instructions.append(TacInstruction(op, new_arg1))
                    
                elif op == 'return':
                    optimized_instructions.append(TacInstruction(op, new_arg1))
                    
                elif op == 'input':
                    invalidate(result)
                    optimized_instructions.append(TacInstruction(op, result=result))
                    
                elif op == 'call':
                    invalidate(result)
                    optimized_instructions.append(TacInstruction(op, new_arg1, new_arg2, result=result))
                    
                else:
                    # Keep other operations (labels, func_begin/end, etc.)
                    optimized_instructions.append(TacInstruction(op, new_arg1, new_arg2, result))
                    
        return optimized_instructions, any_changed

    def eliminate_dead_code(self, instructions):
        # 1. Count uses of all variables/temporaries
        used_vars = set()
        for inst in instructions:
            # We track reads of arg1 and arg2
            # Exception: label results, goto results, input results are not 'uses' of these variables
            if inst.op not in ('label', 'goto', 'func_begin', 'func_end'):
                if inst.arg1 is not None and not self.is_constant(inst.arg1):
                    used_vars.add(str(inst.arg1))
                if inst.arg2 is not None and not self.is_constant(inst.arg2):
                    used_vars.add(str(inst.arg2))

        # 2. Re-sweep to eliminate assignments to unused temporary variables
        optimized = []
        any_changed = False
        
        for inst in instructions:
            result = inst.result
            
            # We only eliminate assignments to temporary variables (t1, t2, ...)
            # We do NOT eliminate assignments to user-declared variables (e.g. x, y, a) 
            # because the user may want to inspect them, or they might be used globally/in output.
            # Temporaries are purely generated by the compiler.
            if result is not None and str(result).startswith('t') and str(result)[1:].isdigit():
                if str(result) not in used_vars:
                    # If it's a call, we cannot remove the call itself (side effects), we just discard the result
                    if inst.op == 'call':
                        optimized.append(TacInstruction('call', inst.arg1, inst.arg2))
                        any_changed = True
                    else:
                        # Skip this assignment completely!
                        any_changed = True
                    continue
            
            optimized.append(inst)
            
        return optimized, any_changed
