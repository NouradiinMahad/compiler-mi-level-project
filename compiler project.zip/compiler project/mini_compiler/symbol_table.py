class Symbol:
    def __init__(self, name, type_, category, scope_level, line, col, params=None):
        self.name = name
        self.type = type_           # For variables: data type; for functions: return type
        self.category = category     # "variable" or "function"
        self.scope_level = scope_level
        self.line = line
        self.col = col
        self.params = params         # List of (type, name) for functions

    def to_dict(self):
        return {
            "name": self.name,
            "type": self.type,
            "category": self.category,
            "scope_level": self.scope_level,
            "line": self.line,
            "column": self.col,
            "params": [{"type": p[0], "name": p[1]} for p in self.params] if self.params else None
        }


class SymbolTable:
    def __init__(self):
        self.scopes = [{}]  # Stack of dictionaries representing scopes. Index 0 is global scope.
        self.current_scope_level = 0
        self.all_symbols = []  # Flat list of all symbols declared across the program (for UI display)

    def enter_scope(self):
        self.scopes.append({})
        self.current_scope_level += 1

    def exit_scope(self):
        if len(self.scopes) > 1:
            self.scopes.pop()
            self.current_scope_level -= 1

    def declare(self, name, type_, category, line, col, params=None):
        # Check if already declared in the CURRENT scope
        if name in self.scopes[-1]:
            return False  # Duplicate declaration
        
        symbol = Symbol(name, type_, category, self.current_scope_level, line, col, params)
        self.scopes[-1][name] = symbol
        self.all_symbols.append(symbol)
        return True

    def lookup(self, name):
        # Search from innermost scope outwards to global scope
        for scope in reversed(self.scopes):
            if name in scope:
                return scope[name]
        return None

    def lookup_local(self, name):
        # Search only the current innermost scope
        if name in self.scopes[-1]:
            return self.scopes[-1][name]
        return None

    def get_all_symbols_dict(self):
        return [sym.to_dict() for sym in self.all_symbols]
