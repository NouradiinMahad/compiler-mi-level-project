class Interpreter:
    def __init__(self):
        self.output = []
        self.steps = 0
        self.max_steps = 100000

    def execute(self, instructions, symbol_table=None):
        self.output = []
        self.steps = 0
        
        # 1. Map labels and function starts
        labels = {}
        for idx, inst in enumerate(instructions):
            if inst.op == 'label':
                labels[str(inst.result)] = idx
            elif inst.op == 'func_begin':
                labels[str(inst.result)] = idx

        # Find entry point: 'main' function or index 0
        pc = 0
        if 'main' in labels:
            pc = labels['main']
        
        # Stack of frames for function calls
        # Each frame is a dictionary of local variables
        frames = [{}] 
        
        # Call stack: list of (return_pc, return_var_name)
        ret_stack = []
        
        # Parameter stack: list of values pushed via 'param'
        param_stack = []
        
        # Globals
        globals_ = {}

        # Resolve helper (takes literal values, vars, or temps)
        def get_val(arg):
            if arg is None:
                return None
            arg_str = str(arg)
            
            # String literals
            if arg_str.startswith('"') and arg_str.endswith('"'):
                return arg_str[1:-1]
            # Character literals
            if arg_str.startswith("'") and arg_str.endswith("'"):
                return arg_str[1:-1]
            # Boolean literals
            if arg_str == 'true':
                return True
            if arg_str == 'false':
                return False
            # Numbers
            try:
                if '.' in arg_str:
                    return float(arg_str)
                return int(arg_str)
            except ValueError:
                # Variable/temporary lookup in innermost frame
                if arg_str in frames[-1]:
                    return frames[-1][arg_str]
                # Globals lookup
                if arg_str in globals_:
                    return globals_[arg_str]
                return 0 # default fallback

        while pc < len(instructions):
            self.steps += 1
            if self.steps > self.max_steps:
                self.output.append("[Runtime Error: Infinite loop detected or step limit exceeded]")
                break
                
            inst = instructions[pc]
            op = inst.op
            arg1 = inst.arg1
            arg2 = inst.arg2
            result = inst.result

            if op == 'func_begin':
                pc += 1
                
            elif op == 'func_end':
                # Reached function end without returning
                if len(ret_stack) > 0:
                    ret_pc, ret_var = ret_stack.pop()
                    frames.pop() # discard local frame
                    pc = ret_pc
                else:
                    break # exit program
                    
            elif op == '=':
                val = get_val(arg1)
                frames[-1][str(result)] = val
                pc += 1
                
            elif op in ('+', '-', '*', '/', '%', '<', '>', '<=', '>=', '==', '!=', '&&', '||'):
                v1 = get_val(arg1)
                v2 = get_val(arg2)
                
                # Coerce to numbers for arithmetic if possible
                try:
                    if op in ('+', '-', '*', '/', '%', '<', '>', '<=', '>='):
                        if not isinstance(v1, (int, float)): v1 = float(v1) if '.' in str(v1) else int(v1)
                        if not isinstance(v2, (int, float)): v2 = float(v2) if '.' in str(v2) else int(v2)
                except:
                    pass

                # Operations execution
                if op == '+': res = v1 + v2
                elif op == '-': res = v1 - v2
                elif op == '*': res = v1 * v2
                elif op == '/':
                    if v2 == 0:
                        self.output.append("[Runtime Error: Division by zero]")
                        break
                    res = v1 / v2
                elif op == '%': res = v1 % v2
                elif op == '<': res = v1 < v2
                elif op == '>': res = v1 > v2
                elif op == '<=': res = v1 <= v2
                elif op == '>=': res = v1 >= v2
                elif op == '==': res = v1 == v2
                elif op == '!=': res = v1 != v2
                elif op == '&&': res = bool(v1 and v2)
                elif op == '||': res = bool(v1 or v2)
                
                frames[-1][str(result)] = res
                pc += 1
                
            elif op == '!':
                v = get_val(arg1)
                frames[-1][str(result)] = not bool(v)
                pc += 1
                
            elif op == 'label':
                pc += 1
                
            elif op == 'goto':
                pc = labels[str(result)]
                
            elif op == 'ifFalse':
                v = get_val(arg1)
                if not v:
                    pc = labels[str(result)]
                else:
                    pc += 1
                    
            elif op == 'print':
                v = get_val(arg1)
                if isinstance(v, bool):
                    self.output.append("true" if v else "false")
                else:
                    self.output.append(str(v))
                pc += 1
                
            elif op == 'input':
                # Prompt/mock reading
                frames[-1][str(result)] = 0
                self.output.append(f"[Input Mock: variable '{result}' populated with default 0]")
                pc += 1
                
            elif op == 'param':
                val = get_val(arg1)
                param_stack.append(val)
                pc += 1
                
            elif op == 'call':
                func_name = str(arg1)
                num_args = int(arg2) if arg2 else 0
                
                args = []
                for _ in range(num_args):
                    if param_stack:
                        args.insert(0, param_stack.pop())
                        
                if func_name not in labels:
                    self.output.append(f"[Runtime Error: Function '{func_name}' not defined]")
                    break
                    
                # Create call frame
                new_frame = {}
                
                # Retrieve parameters mapping from symbol table
                if symbol_table:
                    func_sym = symbol_table.lookup(func_name)
                    if func_sym and func_sym.params:
                        for idx, (p_type, p_name) in enumerate(func_sym.params):
                            if idx < len(args):
                                new_frame[p_name] = args[idx]
                                
                # Push context
                ret_stack.append((pc + 1, str(result) if result else None))
                frames.append(new_frame)
                
                pc = labels[func_name]
                
            elif op == 'return':
                ret_val = get_val(arg1) if arg1 is not None else None
                if len(ret_stack) > 0:
                    ret_pc, ret_var = ret_stack.pop()
                    frames.pop() # destroy frame
                    if ret_var and ret_val is not None:
                        frames[-1][ret_var] = ret_val
                    pc = ret_pc
                else:
                    break # exit program
            else:
                pc += 1
                
        return "\n".join(self.output)
